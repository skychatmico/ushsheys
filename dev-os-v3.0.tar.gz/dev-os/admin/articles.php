<?php
/**
 * DEV-OS Articles Management
 * إدارة المقالات
 */

require_once '../includes/config.php';

try {
    $db = getDB();
    
    // جلب جميع المقالات
    $articles = $db->query("
        SELECT * FROM articles 
        ORDER BY created_at DESC
    ")->fetchAll();
    
} catch (Exception $e) {
    $articles = [];
}

// معالجة الحذف
if (isset($_GET['delete'])) {
    try {
        $stmt = $db->prepare("DELETE FROM articles WHERE id = ?");
        $stmt->execute([$_GET['delete']]);
        header("Location: articles.php");
        exit;
    } catch (Exception $e) {
        $error = 'حدث خطأ أثناء الحذف';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المقالات | DEV-OS</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        .admin-sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--bg-secondary);
            border-left: 1px solid var(--glass-border);
            z-index: 100;
            overflow-y: auto;
        }
        
        .admin-main {
            margin-right: 280px;
            min-height: 100vh;
            padding: 30px;
        }
        
        .admin-logo {
            padding: 30px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-nav {
            padding: 20px 0;
        }
        
        .admin-nav-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 30px;
            color: var(--text-secondary);
            transition: var(--transition);
            border-right: 3px solid transparent;
        }
        
        .admin-nav-item:hover,
        .admin-nav-item.active {
            background: var(--glass-bg);
            color: var(--text-primary);
            border-right-color: var(--neon-blue);
        }
        
        .admin-nav-item i {
            width: 24px;
            text-align: center;
            color: var(--neon-blue);
        }
        
        .admin-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-title {
            font-size: 28px;
            font-weight: 700;
        }
        
        @media (max-width: 1024px) {
            .admin-sidebar {
                transform: translateX(100%);
            }
            
            .admin-main {
                margin-right: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <div class="admin-logo">
            <a href="../index.php" class="logo">
                <div class="logo-icon">D</div>
                <span class="logo-text">DEV-OS</span>
            </a>
        </div>
        
        <nav class="admin-nav">
            <a href="index.php" class="admin-nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="articles.php" class="admin-nav-item active">
                <i class="fas fa-file-alt"></i>
                <span>المقالات</span>
            </a>
            <a href="apps.php" class="admin-nav-item">
                <i class="fas fa-mobile-alt"></i>
                <span>التطبيقات</span>
            </a>
            <a href="add-article.php" class="admin-nav-item">
                <i class="fas fa-plus-circle"></i>
                <span>إضافة مقال</span>
            </a>
            <a href="add-app.php" class="admin-nav-item">
                <i class="fas fa-upload"></i>
                <span>رفع تطبيق</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="admin-main">
        <div class="admin-header">
            <h1 class="admin-title">إدارة المقالات</h1>
            <a href="add-article.php" class="btn btn-primary btn-sm">
                <i class="fas fa-plus"></i>
                مقال جديد
            </a>
        </div>
        
        <div class="glass-card" style="padding: 0; overflow: hidden;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>العنوان</th>
                        <th>القسم</th>
                        <th>الكاتب</th>
                        <th>المشاهدات</th>
                        <th>الحالة</th>
                        <th>التاريخ</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($articles as $article): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($article['title']); ?></td>
                        <td><?php echo htmlspecialchars($article['category']); ?></td>
                        <td><?php echo htmlspecialchars($article['author']); ?></td>
                        <td><?php echo number_format($article['views']); ?></td>
                        <td>
                            <span style="color: <?php echo $article['status'] === 'published' ? 'var(--success)' : 'var(--warning)'; ?>">
                                <?php echo $article['status'] === 'published' ? 'منشور' : 'مسودة'; ?>
                            </span>
                        </td>
                        <td><?php echo date('Y/m/d', strtotime($article['created_at'])); ?></td>
                        <td>
                            <div class="table-actions">
                                <a href="../pages/article.php?slug=<?php echo $article['slug']; ?>" class="table-action" title="عرض" target="_blank">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="edit-article.php?id=<?php echo $article['id']; ?>" class="table-action" title="تعديل">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="?delete=<?php echo $article['id']; ?>" 
                                   class="table-action delete" 
                                   title="حذف"
                                   onclick="return confirm('هل أنت متأكد من حذف هذا المقال؟')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <?php if (empty($articles)): ?>
        <div class="empty-state" style="margin-top: 40px;">
            <i class="fas fa-file-alt"></i>
            <h3>لا توجد مقالات</h3>
            <p>أضف مقالك الأول الآن</p>
            <a href="add-article.php" class="btn btn-primary" style="margin-top: 20px;">
                <i class="fas fa-plus"></i>
                إضافة مقال
            </a>
        </div>
        <?php endif; ?>
    </main>
</body>
</html>
