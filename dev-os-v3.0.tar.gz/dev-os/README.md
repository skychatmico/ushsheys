# DEV-OS v3.0 - نظام التشغيل الرقمي

نظام تشغيل رقمي متكامل للمطورين، يجمع بين التطبيقات البرمجية، المقالات التقنية، والأدوات المتقدمة في بيئة زجاجية مستقبلية.

![Version](https://img.shields.io/badge/version-3.0-blue)
![PHP](https://img.shields.io/badge/PHP-7.4+-purple)
![MySQL](https://img.shields.io/badge/MySQL-5.7+-orange)

## المميزات الرئيسية

### 1. نظام البحث الفوري (Live Search)
- عدسة بحث تتوسع عند النقر
- طلبات AJAX للبحث في قاعدة البيانات
- نتائج فورية من جداول المقالات والتطبيقات
- اقتراحات زجاجية باهتة

### 2. لوحة تحكم المسؤول
- رفع تطبيقات APK
- إضافة وتعديل المقالات
- إحصائيات شاملة
- إدارة المحتوى

### 3. تصميم Glassmorphism
- خلفية زجاجية ضبابية
- تأثيرات نيون زرقاء
- رسوم متحركة سلسة
- دعم كامل للجوال

### 4. هيكل الصفحات
- الصفحة الرئيسية مع آخر التحديثات
- صفحة المتجر مع فلترة حسب الأقسام
- صفحة المدونة مع عرض المقالات
- صفحات عرض فردية للمحتوى

## متطلبات التشغيل

- PHP 7.4 أو أعلى
- MySQL 5.7 أو أعلى
- خادم ويب (Apache/Nginx)
- إضافة PDO لـ PHP

## التثبيت

### 1. إنشاء قاعدة البيانات

```sql
-- استيراد ملف database.sql
mysql -u root -p
CREATE DATABASE dev_os CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dev_os;
SOURCE database.sql;
```

أو يمكنك استيراد الملف `database.sql` مباشرة من خلال phpMyAdmin.

### 2. إعداد الإعدادات

افتح ملف `includes/config.php` وعدل إعدادات قاعدة البيانات:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'dev_os');
define('DB_USER', 'root');
define('DB_PASS', 'your_password');
```

### 3. رفع الملفات

ارفع جميع ملفات المشروع إلى خادم الويب الخاص بك.

### 4. صلاحيات المجلدات

تأكد من أن المجلد `uploads/apps` لديه صلاحيات الكتابة:

```bash
chmod 755 uploads/apps
```

## هيكل المشروع

```
dev-os/
├── admin/              # لوحة التحكم
│   ├── index.php      # الصفحة الرئيسية للوحة
│   ├── articles.php   # إدارة المقالات
│   ├── apps.php       # إدارة التطبيقات
│   ├── add-article.php
│   ├── add-app.php
│   ├── edit-article.php
│   └── edit-app.php
├── css/
│   └── style.css      # ملف الأنماط الرئيسي
├── includes/
│   ├── config.php     # الإعدادات والدوال
│   └── search.php     # نظام البحث
├── js/
│   └── main.js        # الجافاسكربت الرئيسي
├── pages/             # صفحات الموقع
│   ├── store.php      # المتجر
│   ├── blog.php       # المدونة
│   ├── article.php    # عرض مقال
│   ├── app.php        # عرض تطبيق
│   └── download.php   # تحميل تطبيق
├── uploads/           # مجلد الرفع
│   └── apps/          # ملفات APK
├── database.sql       # قاعدة البيانات
├── index.php          # الصفحة الرئيسية
└── README.md          # هذا الملف
```

## الجداول في قاعدة البيانات

### جدول المقالات (articles)
| الحقل | النوع | الوصف |
|-------|-------|-------|
| id | INT | معرف فريد |
| title | VARCHAR | عنوان المقال |
| slug | VARCHAR | الرابط المميز |
| content | TEXT | محتوى المقال |
| excerpt | VARCHAR | ملخص المقال |
| category | VARCHAR | القسم |
| tags | VARCHAR | الوسوم |
| author | VARCHAR | الكاتب |
| views | INT | عدد المشاهدات |
| status | ENUM | الحالة |

### جدول التطبيقات (apps)
| الحقل | النوع | الوصف |
|-------|-------|-------|
| id | INT | معرف فريد |
| name | VARCHAR | اسم التطبيق |
| slug | VARCHAR | الرابط المميز |
| description | TEXT | الوصف |
| version | VARCHAR | الإصدار |
| file_path | VARCHAR | مسار الملف |
| file_size | BIGINT | حجم الملف |
| category | VARCHAR | القسم |
| downloads | INT | عدد التحميلات |
| status | ENUM | الحالة |

## الاستخدام

### إضافة مقال جديد
1. انتقل إلى `admin/add-article.php`
2. أدخل عنوان المقال والمحتوى
3. اختر القسم والحالة
4. اضغط "حفظ المقال"

### رفع تطبيق جديد
1. انتقل إلى `admin/add-app.php`
2. اختر ملف APK
3. أدخل اسم التطبيق والإصدار
4. اضغط "رفع التطبيق"

### البحث
- اضغط على أيقونة البحث في الهيدر
- اكتب اسم التطبيق أو المقال
- اختر من النتائج الظاهرة

## التخصيص

### تغيير الألوان
افتح `css/style.css` وعدل المتغيرات:

```css
:root {
    --bg-primary: #050505;
    --neon-blue: #00d4ff;
    --neon-purple: #a855f7;
    /* ... */
}
```

### إضافة أقسام جديدة
عدل ملف `admin/add-article.php` أو `admin/add-app.php` وأضف خيارات جديدة في قائمة `select`.

## الأمان

- استخدام PDO للتعامل الآمن مع قاعدة البيانات
- تنظيف المدخلات باستخدام `htmlspecialchars()`
- حماية من هجمات XSS
- التحقق من صلاحيات الملفات المرفوعة

## الترخيص

هذا المشروع مفتوح المصدر ومتاح للاستخدام الشخصي والتجاري.

## الدعم

للاستفسارات والدعم الفني:
- البريد: support@dev-os.com
- تويتر: @dev_os

---

**تم التطوير بواسطة DEV-OS Team** © 2024
