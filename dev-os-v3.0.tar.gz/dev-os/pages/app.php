<?php
/**
 * DEV-OS Single App Page
 * صفحة عرض التطبيق
 */

require_once '../includes/config.php';

$slug = isset($_GET['slug']) ? cleanInput($_GET['slug']) : '';

if (empty($slug)) {
    redirect('store.php');
}

try {
    $db = getDB();
    
    // جلب التطبيق
    $stmt = $db->prepare("
        SELECT * FROM apps 
        WHERE slug = ? AND status = 'active'
    ");
    $stmt->execute([$slug]);
    $app = $stmt->fetch();
    
    if (!$app) {
        redirect('store.php');
    }
    
    // تطبيقات ذات صلة
    $related = $db->prepare("
        SELECT * FROM apps 
        WHERE category = ? AND id != ? AND status = 'active'
        ORDER BY downloads DESC
        LIMIT 3
    ");
    $related->execute([$app['category'], $app['id']]);
    $relatedApps = $related->fetchAll();
    
} catch (Exception $e) {
    redirect('store.php');
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($app['name']); ?> | DEV-OS</title>
    <meta name="description" content="<?php echo excerpt($app['description'], 150); ?>">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        .app-page {
            max-width: 1000px;
            margin: 0 auto;
            padding: 120px 30px 60px;
        }
        
        .app-hero {
            display: flex;
            gap: 50px;
            align-items: flex-start;
            margin-bottom: 60px;
        }
        
        .app-icon-main {
            width: 150px;
            height: 150px;
            background: linear-gradient(135deg, var(--neon-blue), var(--neon-purple));
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 72px;
            flex-shrink: 0;
            box-shadow: 0 20px 60px rgba(0, 212, 255, 0.3);
        }
        
        .app-info {
            flex: 1;
        }
        
        .app-category {
            display: inline-block;
            font-size: 12px;
            font-weight: 600;
            color: var(--neon-blue);
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 15px;
            padding: 6px 18px;
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
        }
        
        .app-name-main {
            font-size: clamp(28px, 4vw, 42px);
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        .app-description {
            font-size: 16px;
            color: var(--text-secondary);
            line-height: 1.9;
            margin-bottom: 30px;
        }
        
        .app-stats-row {
            display: flex;
            gap: 40px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        
        .app-stat-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .app-stat-label {
            font-size: 12px;
            color: var(--text-muted);
            text-transform: uppercase;
        }
        
        .app-stat-value {
            font-size: 20px;
            font-weight: 700;
            color: var(--neon-blue);
        }
        
        .app-actions {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .app-details {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-lg);
            padding: 40px;
            backdrop-filter: blur(var(--blur-amount));
        }
        
        .app-details-title {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .app-details-content {
            font-size: 16px;
            line-height: 2;
            color: var(--text-secondary);
        }
        
        .app-details-content p {
            margin-bottom: 20px;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 25px;
            margin-top: 40px;
        }
        
        .info-item {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-md);
            padding: 20px;
        }
        
        .info-item-label {
            font-size: 12px;
            color: var(--text-muted);
            margin-bottom: 8px;
        }
        
        .info-item-value {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .related-section {
            margin-top: 80px;
        }
        
        .related-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .related-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
        }
        
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 30px;
            color: var(--text-secondary);
            transition: var(--transition);
        }
        
        .back-link:hover {
            color: var(--neon-blue);
        }
        
        @media (max-width: 768px) {
            .app-hero {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }
            
            .app-icon-main {
                width: 120px;
                height: 120px;
                font-size: 56px;
            }
            
            .app-stats-row {
                justify-content: center;
            }
            
            .app-actions {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- خلفية الشبكة -->
    <div class="bg-grid"></div>
    <div class="floating-particles"></div>
    
    <!-- الهيدر -->
    <header class="main-header">
        <div class="header-content">
            <a href="../index.php" class="logo">
                <div class="logo-icon">D</div>
                <span class="logo-text">DEV-OS</span>
                <span class="version-badge">v3.0</span>
            </a>
            
            <nav class="header-nav">
                <a href="../index.php" class="nav-link">الرئيسية</a>
                <a href="store.php" class="nav-link active">المتجر</a>
                <a href="blog.php" class="nav-link">المدونة</a>
                <a href="../admin/index.php" class="nav-link">لوحة التحكم</a>
            </nav>
            
            <div style="display: flex; align-items: center; gap: 15px;">
                <div class="search-container">
                    <div class="search-lens">
                        <i class="fas fa-search"></i>
                    </div>
                    <div class="search-expand">
                        <div class="search-input-wrapper">
                            <input type="text" class="search-input" placeholder="ابحث...">
                            <button class="search-close">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="search-results"></div>
                </div>
                
                <button class="menu-toggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </div>
    </header>
    
    <!-- القائمة الجانبية -->
    <div class="drawer-overlay"></div>
    <aside class="side-drawer">
        <div class="drawer-header">
            <h3 class="drawer-title">القائمة</h3>
            <button class="drawer-close">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <nav class="drawer-nav">
            <a href="../index.php" class="drawer-nav-item">
                <i class="fas fa-home"></i>
                <span>الرئيسية</span>
            </a>
            <a href="store.php" class="drawer-nav-item active">
                <i class="fas fa-store"></i>
                <span>المتجر</span>
            </a>
            <a href="blog.php" class="drawer-nav-item">
                <i class="fas fa-blog"></i>
                <span>المدونة</span>
            </a>
            <a href="../admin/index.php" class="drawer-nav-item">
                <i class="fas fa-cog"></i>
                <span>لوحة التحكم</span>
            </a>
        </nav>
    </aside>
    
    <!-- المحتوى الرئيسي -->
    <main class="main-content">
        <div class="app-page">
            <a href="store.php" class="back-link">
                <i class="fas fa-arrow-right"></i>
                العودة للمتجر
            </a>
            
            <div class="app-hero">
                <div class="app-icon-main">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                
                <div class="app-info">
                    <span class="app-category"><?php echo htmlspecialchars($app['category']); ?></span>
                    <h1 class="app-name-main"><?php echo htmlspecialchars($app['name']); ?></h1>
                    <p class="app-description">
                        <?php echo nl2br(htmlspecialchars($app['description'])); ?>
                    </p>
                    
                    <div class="app-stats-row">
                        <div class="app-stat-item">
                            <span class="app-stat-label">الإصدار</span>
                            <span class="app-stat-value"><?php echo htmlspecialchars($app['version']); ?></span>
                        </div>
                        <div class="app-stat-item">
                            <span class="app-stat-label">الحجم</span>
                            <span class="app-stat-value"><?php echo formatFileSize($app['file_size']); ?></span>
                        </div>
                        <div class="app-stat-item">
                            <span class="app-stat-label">التحميلات</span>
                            <span class="app-stat-value"><?php echo number_format($app['downloads']); ?></span>
                        </div>
                        <div class="app-stat-item">
                            <span class="app-stat-label">التقييم</span>
                            <span class="app-stat-value">
                                <i class="fas fa-star" style="color: #fbbf24;"></i>
                                <?php echo $app['rating']; ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="app-actions">
                        <a href="download.php?slug=<?php echo $app['slug']; ?>" class="btn btn-primary btn-lg">
                            <i class="fas fa-download"></i>
                            تحميل التطبيق
                        </a>
                        <button class="btn btn-secondary btn-lg" onclick="shareApp()">
                            <i class="fas fa-share-alt"></i>
                            مشاركة
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-item-label">المطور</div>
                    <div class="info-item-value"><?php echo htmlspecialchars($app['developer']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-item-label">تاريخ الإضافة</div>
                    <div class="info-item-value"><?php echo date('Y/m/d', strtotime($app['created_at'])); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-item-label">آخر تحديث</div>
                    <div class="info-item-value"><?php echo date('Y/m/d', strtotime($app['updated_at'])); ?></div>
                </div>
            </div>
        </div>
        
        <!-- تطبيقات ذات صلة -->
        <?php if (!empty($relatedApps)): ?>
        <section class="related-section" style="max-width: 1000px; margin: 80px auto; padding: 0 30px;">
            <h2 class="related-title">تطبيقات ذات صلة</h2>
            <div class="related-grid">
                <?php foreach ($relatedApps as $related): ?>
                <a href="app.php?slug=<?php echo $related['slug']; ?>" class="glass-card" style="text-decoration: none; text-align: center; padding: 30px;">
                    <div style="width: 60px; height: 60px; background: linear-gradient(135deg, var(--neon-blue), var(--neon-purple)); border-radius: 15px; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; font-size: 28px;">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <span style="font-size: 11px; color: var(--neon-blue); margin-bottom: 8px; display: block;">
                        <?php echo htmlspecialchars($related['category']); ?>
                    </span>
                    <h4 style="font-size: 16px; margin-bottom: 8px;">
                        <?php echo htmlspecialchars($related['name']); ?>
                    </h4>
                    <p style="font-size: 13px; color: var(--text-muted);">
                        <?php echo formatFileSize($related['file_size']); ?> • v<?php echo htmlspecialchars($related['version']); ?>
                    </p>
                </a>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>
    </main>
    
    <!-- الفوتر -->
    <footer class="main-footer">
        <div class="footer-content">
            <div class="footer-section">
                <h4>DEV-OS</h4>
                <p>نظام تشغيل رقمي متكامل للمطورين.</p>
            </div>
            <div class="footer-section">
                <h4>روابط سريعة</h4>
                <ul class="footer-links">
                    <li><a href="../index.php">الرئيسية</a></li>
                    <li><a href="store.php">المتجر</a></li>
                    <li><a href="blog.php">المدونة</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> DEV-OS. جميع الحقوق محفوظة.</p>
        </div>
    </footer>
    
    <!-- Scripts -->
    <script src="../js/main.js"></script>
    <script>
        function shareApp() {
            if (navigator.share) {
                navigator.share({
                    title: '<?php echo addslashes($app['name']); ?>',
                    text: '<?php echo addslashes(excerpt($app['description'], 100)); ?>',
                    url: window.location.href
                });
            } else {
                // نسخ الرابط
                navigator.clipboard.writeText(window.location.href).then(() => {
                    alert('تم نسخ الرابط!');
                });
            }
        }
    </script>
</body>
</html>
