<?php
/**
 * DEV-OS Add App
 * رفع تطبيق جديد
 */

require_once '../includes/config.php';

$message = '';
$messageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = getDB();
        
        $name = cleanInput($_POST['name']);
        $slug = createSlug($name);
        $description = $_POST['description'];
        $version = cleanInput($_POST['version']);
        $category = cleanInput($_POST['category']);
        $developer = cleanInput($_POST['developer']);
        
        // التحقق من البيانات
        if (empty($name) || empty($_FILES['app_file']['name'])) {
            throw new Exception('اسم التطبيق والملف مطلوبان');
        }
        
        // التأكد من عدم تكرار الـ slug
        $checkStmt = $db->prepare("SELECT id FROM apps WHERE slug = ?");
        $checkStmt->execute([$slug]);
        if ($checkStmt->fetch()) {
            $slug .= '-' . time();
        }
        
        // معالجة رفع الملف
        $uploadDir = '../uploads/apps/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $fileName = $slug . '.apk';
        $filePath = $uploadDir . $fileName;
        $dbFilePath = 'uploads/apps/' . $fileName;
        
        if (!move_uploaded_file($_FILES['app_file']['tmp_name'], $filePath)) {
            throw new Exception('فشل رفع الملف');
        }
        
        $fileSize = filesize($filePath);
        
        $stmt = $db->prepare("
            INSERT INTO apps (name, slug, description, version, file_path, file_size, category, developer)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([$name, $slug, $description, $version, $dbFilePath, $fileSize, $category, $developer]);
        
        $message = 'تم رفع التطبيق بنجاح!';
        
    } catch (Exception $e) {
        $message = $e->getMessage();
        $messageType = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>رفع تطبيق | DEV-OS</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        .admin-sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--bg-secondary);
            border-left: 1px solid var(--glass-border);
            z-index: 100;
            overflow-y: auto;
        }
        
        .admin-main {
            margin-right: 280px;
            min-height: 100vh;
            padding: 30px;
        }
        
        .admin-logo {
            padding: 30px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-nav {
            padding: 20px 0;
        }
        
        .admin-nav-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 30px;
            color: var(--text-secondary);
            transition: var(--transition);
            border-right: 3px solid transparent;
        }
        
        .admin-nav-item:hover,
        .admin-nav-item.active {
            background: var(--glass-bg);
            color: var(--text-primary);
            border-right-color: var(--neon-blue);
        }
        
        .admin-nav-item i {
            width: 24px;
            text-align: center;
            color: var(--neon-blue);
        }
        
        .admin-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-title {
            font-size: 28px;
            font-weight: 700;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }
        
        .form-grid .form-group.full-width {
            grid-column: 1 / -1;
        }
        
        .file-upload-area {
            border: 2px dashed var(--glass-border);
            border-radius: var(--radius-md);
            padding: 60px;
            text-align: center;
            transition: var(--transition);
            cursor: pointer;
        }
        
        .file-upload-area:hover {
            border-color: var(--neon-blue);
            background: rgba(0, 212, 255, 0.05);
        }
        
        .file-upload-area i {
            font-size: 48px;
            color: var(--neon-blue);
            margin-bottom: 15px;
        }
        
        .file-upload-area p {
            color: var(--text-secondary);
            margin-bottom: 10px;
        }
        
        .file-upload-area small {
            color: var(--text-muted);
        }
        
        #file-name {
            margin-top: 15px;
            padding: 10px;
            background: var(--glass-bg);
            border-radius: var(--radius-sm);
            color: var(--neon-blue);
            display: none;
        }
        
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .admin-main {
                margin-right: 0;
            }
            
            .admin-sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <div class="admin-logo">
            <a href="../index.php" class="logo">
                <div class="logo-icon">D</div>
                <span class="logo-text">DEV-OS</span>
            </a>
        </div>
        
        <nav class="admin-nav">
            <a href="index.php" class="admin-nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="articles.php" class="admin-nav-item">
                <i class="fas fa-file-alt"></i>
                <span>المقالات</span>
            </a>
            <a href="apps.php" class="admin-nav-item">
                <i class="fas fa-mobile-alt"></i>
                <span>التطبيقات</span>
            </a>
            <a href="add-article.php" class="admin-nav-item">
                <i class="fas fa-plus-circle"></i>
                <span>إضافة مقال</span>
            </a>
            <a href="add-app.php" class="admin-nav-item active">
                <i class="fas fa-upload"></i>
                <span>رفع تطبيق</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="admin-main">
        <div class="admin-header">
            <h1 class="admin-title">رفع تطبيق جديد</h1>
            <a href="index.php" class="btn btn-secondary btn-sm">
                <i class="fas fa-arrow-right"></i>
                العودة
            </a>
        </div>
        
        <?php if ($message): ?>
            <?php echo showAlert($message, $messageType); ?>
        <?php endif; ?>
        
        <div class="glass-card">
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="form-grid">
                    <div class="form-group full-width">
                        <label class="form-label">ملف التطبيق (APK)</label>
                        <div class="file-upload-area" onclick="document.getElementById('app-file').click()">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>اضغط هنا لاختيار الملف أو اسحب الملف هنا</p>
                            <small>يُقبل فقط ملفات APK (الحد الأقصى 100 ميجابايت)</small>
                            <input type="file" id="app-file" name="app_file" accept=".apk" style="display: none;" required onchange="showFileName(this)">
                            <div id="file-name"></div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">اسم التطبيق</label>
                        <input type="text" name="name" class="form-input" placeholder="أدخل اسم التطبيق" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">الإصدار</label>
                        <input type="text" name="version" class="form-input" placeholder="مثال: 1.0.0" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">القسم</label>
                        <select name="category" class="form-select">
                            <option value="أدوات المطورين">أدوات المطورين</option>
                            <option value="محررات الأكواد">محررات الأكواد</option>
                            <option value="قواعد البيانات">قواعد البيانات</option>
                            <option value="أدوات Git">أدوات Git</option>
                            <option value="اختبار APIs">اختبار APIs</option>
                            <option value="أخرى">أخرى</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">المطور</label>
                        <input type="text" name="developer" class="form-input" value="DEV-OS">
                    </div>
                    
                    <div class="form-group full-width">
                        <label class="form-label">وصف التطبيق</label>
                        <textarea name="description" class="form-textarea" rows="5" placeholder="وصف مفصل للتطبيق ومميزاته..."></textarea>
                    </div>
                    
                    <div class="form-group full-width">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-upload"></i>
                            رفع التطبيق
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>
    
    <script>
        function showFileName(input) {
            const fileNameDiv = document.getElementById('file-name');
            if (input.files && input.files[0]) {
                fileNameDiv.textContent = 'الملف المختار: ' + input.files[0].name;
                fileNameDiv.style.display = 'block';
            }
        }
        
        // Drag and drop
        const uploadArea = document.querySelector('.file-upload-area');
        
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = 'var(--neon-blue)';
            uploadArea.style.background = 'rgba(0, 212, 255, 0.1)';
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.style.borderColor = '';
            uploadArea.style.background = '';
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '';
            uploadArea.style.background = '';
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                document.getElementById('app-file').files = files;
                showFileName(document.getElementById('app-file'));
            }
        });
    </script>
</body>
</html>
