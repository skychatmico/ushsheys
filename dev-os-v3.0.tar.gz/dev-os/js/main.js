/**
 * DEV-OS Main JavaScript
 * نظام تشغيل رقمي - الجافاسكربت الرئيسي
 */

document.addEventListener('DOMContentLoaded', function() {
    // ========================================
    // تهيئة المكونات
    // ========================================
    initSearch();
    initSideDrawer();
    initScrollAnimations();
    initParticles();
    initCodeBlocks();
    initMobileMenu();
});

// ========================================
// نظام البحث الفوري
// ========================================
function initSearch() {
    const searchLens = document.querySelector('.search-lens');
    const searchExpand = document.querySelector('.search-expand');
    const searchInput = document.querySelector('.search-input');
    const searchClose = document.querySelector('.search-close');
    const searchResults = document.querySelector('.search-results');
    
    if (!searchLens || !searchExpand) return;
    
    let searchTimeout;
    
    // فتح حقل البحث
    searchLens.addEventListener('click', function() {
        searchExpand.classList.add('active');
        searchInput.focus();
    });
    
    // إغلاق حقل البحث
    searchClose.addEventListener('click', function() {
        searchExpand.classList.remove('active');
        searchResults.classList.remove('active');
        searchInput.value = '';
    });
    
    // البحث الفوري
    searchInput.addEventListener('input', function() {
        const query = this.value.trim();
        
        clearTimeout(searchTimeout);
        
        if (query.length < 2) {
            searchResults.classList.remove('active');
            return;
        }
        
        // تأخير بسيط لتجنب الطلبات المتكررة
        searchTimeout = setTimeout(() => {
            performSearch(query);
        }, 300);
    });
    
    // إغلاق النتائج عند النقر خارجها
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.search-container')) {
            searchResults.classList.remove('active');
        }
    });
}

// دالة البحث AJAX
function performSearch(query) {
    const searchResults = document.querySelector('.search-results');
    
    fetch('includes/search.php?q=' + encodeURIComponent(query))
        .then(response => response.json())
        .then(data => {
            displaySearchResults(data, query);
        })
        .catch(error => {
            console.error('Search error:', error);
            searchResults.innerHTML = '<div class="search-no-results">حدث خطأ في البحث</div>';
            searchResults.classList.add('active');
        });
}

// عرض نتائج البحث
function displaySearchResults(data, query) {
    const searchResults = document.querySelector('.search-results');
    
    if (data.length === 0) {
        searchResults.innerHTML = `
            <div class="search-no-results">
                <i class="fas fa-search" style="font-size: 24px; margin-bottom: 10px; display: block;"></i>
                لا توجد نتائج لـ "${escapeHtml(query)}"
            </div>
        `;
        searchResults.classList.add('active');
        return;
    }
    
    let html = '';
    data.forEach(item => {
        const typeLabel = item.type === 'article' ? 'مقال' : 'تطبيق';
        const icon = item.type === 'article' ? 'fa-file-alt' : 'fa-mobile-alt';
        const url = item.type === 'article' ? `article.php?slug=${item.slug}` : `app.php?slug=${item.slug}`;
        
        html += `
            <a href="${url}" class="search-result-item">
                <div class="search-result-type">
                    <i class="fas ${icon}"></i> ${typeLabel}
                </div>
                <div class="search-result-title">${escapeHtml(item.title)}</div>
                <div class="search-result-desc">${escapeHtml(item.excerpt || '')}</div>
            </a>
        `;
    });
    
    searchResults.innerHTML = html;
    searchResults.classList.add('active');
}

// ========================================
// القائمة الجانبية
// ========================================
function initSideDrawer() {
    const menuToggle = document.querySelector('.menu-toggle');
    const drawerOverlay = document.querySelector('.drawer-overlay');
    const sideDrawer = document.querySelector('.side-drawer');
    const drawerClose = document.querySelector('.drawer-close');
    
    if (!menuToggle || !sideDrawer) return;
    
    function openDrawer() {
        menuToggle.classList.add('active');
        drawerOverlay.classList.add('active');
        sideDrawer.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    
    function closeDrawer() {
        menuToggle.classList.remove('active');
        drawerOverlay.classList.remove('active');
        sideDrawer.classList.remove('active');
        document.body.style.overflow = '';
    }
    
    menuToggle.addEventListener('click', function() {
        if (sideDrawer.classList.contains('active')) {
            closeDrawer();
        } else {
            openDrawer();
        }
    });
    
    drawerOverlay.addEventListener('click', closeDrawer);
    drawerClose.addEventListener('click', closeDrawer);
    
    // إغلاق بالضغط على Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && sideDrawer.classList.contains('active')) {
            closeDrawer();
        }
    });
}

// ========================================
// أنيميشن التمرير
// ========================================
function initScrollAnimations() {
    const fadeElements = document.querySelectorAll('.fade-in');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    fadeElements.forEach(el => observer.observe(el));
}

// ========================================
// الجسيمات المتحركة
// ========================================
function initParticles() {
    const container = document.querySelector('.floating-particles');
    if (!container) return;
    
    const particleCount = 25;
    
    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 15 + 's';
        particle.style.animationDuration = (15 + Math.random() * 10) + 's';
        container.appendChild(particle);
    }
}

// ========================================
// كتل الأكواد البرمجية
// ========================================
function initCodeBlocks() {
    const codeBlocks = document.querySelectorAll('.code-block');
    
    codeBlocks.forEach(block => {
        const copyBtn = block.querySelector('.code-copy');
        const code = block.querySelector('code');
        
        if (copyBtn && code) {
            copyBtn.addEventListener('click', function() {
                const text = code.textContent;
                navigator.clipboard.writeText(text).then(() => {
                    const originalText = copyBtn.innerHTML;
                    copyBtn.innerHTML = '<i class="fas fa-check"></i> تم النسخ';
                    copyBtn.style.color = 'var(--success)';
                    
                    setTimeout(() => {
                        copyBtn.innerHTML = originalText;
                        copyBtn.style.color = '';
                    }, 2000);
                });
            });
        }
    });
    
    // تلوين الكود بشكل بسيط
    highlightCode();
}

function highlightCode() {
    const codeBlocks = document.querySelectorAll('pre code');
    
    codeBlocks.forEach(block => {
        let html = block.innerHTML;
        
        // الكلمات المفتاحية
        const keywords = ['function', 'const', 'let', 'var', 'if', 'else', 'for', 'while', 'return', 'class', 'import', 'export', 'public', 'static', 'void', 'int', 'string'];
        keywords.forEach(keyword => {
            const regex = new RegExp(`\\b${keyword}\\b`, 'g');
            html = html.replace(regex, `<span class="keyword">${keyword}</span>`);
        });
        
        // النصوص
        html = html.replace(/(['"`])(.*?)\1/g, '<span class="string">$1$2$1</span>');
        
        // التعليقات
        html = html.replace(/(\/\/.*$)/gm, '<span class="comment">$1</span>');
        html = html.replace(/(\/\*[\s\S]*?\*\/)/g, '<span class="comment">$1</span>');
        
        // الأرقام
        html = html.replace(/\b(\d+)\b/g, '<span class="number">$1</span>');
        
        // الدوال
        html = html.replace(/(\w+)(?=\()/g, '<span class="function">$1</span>');
        
        block.innerHTML = html;
    });
}

// ========================================
// القائمة المتنقلة
// ========================================
function initMobileMenu() {
    // يمكن إضافة منطق إضافي للقائمة المتنقلة هنا
}

// ========================================
// دوال مساعدة
// ========================================
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// تأثير الكتابة التدريجي
function typeWriter(element, text, speed = 50) {
    let i = 0;
    element.textContent = '';
    
    function type() {
        if (i < text.length) {
            element.textContent += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    
    type();
}

// عداد الأرقام المتحرك
function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);
    
    function update() {
        start += increment;
        if (start < target) {
            element.textContent = Math.floor(start).toLocaleString();
            requestAnimationFrame(update);
        } else {
            element.textContent = target.toLocaleString();
        }
    }
    
    update();
}

// تأثير الموجة
function createRipple(event, element) {
    const ripple = document.createElement('span');
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = (event.clientX - rect.left - size / 2) + 'px';
    ripple.style.top = (event.clientY - rect.top - size / 2) + 'px';
    ripple.classList.add('ripple');
    
    element.appendChild(ripple);
    
    setTimeout(() => ripple.remove(), 600);
}

// ========================================
// تأثيرات الهيدر عند التمرير
// ========================================
let lastScroll = 0;

window.addEventListener('scroll', function() {
    const header = document.querySelector('.main-header');
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 100) {
        header.style.background = 'rgba(5, 5, 5, 0.95)';
        header.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.3)';
    } else {
        header.style.background = 'rgba(5, 5, 5, 0.8)';
        header.style.boxShadow = 'none';
    }
    
    lastScroll = currentScroll;
});

// ========================================
// Lazy Loading للصور
// ========================================
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    document.querySelectorAll('img.lazy').forEach(img => {
        imageObserver.observe(img);
    });
}
