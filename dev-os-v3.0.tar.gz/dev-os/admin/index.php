<?php
/**
 * DEV-OS Admin Dashboard
 * لوحة تحكم المسؤول
 */

require_once '../includes/config.php';

// التحقق من تسجيل الدخول (مؤقتاً معطل للتجربة)
// if (!isAdmin()) {
//     redirect('login.php');
// }

try {
    $db = getDB();
    
    // إحصائيات
    $stats = [
        'articles' => $db->query("SELECT COUNT(*) FROM articles")->fetchColumn(),
        'apps' => $db->query("SELECT COUNT(*) FROM apps")->fetchColumn(),
        'downloads' => $db->query("SELECT SUM(downloads) FROM apps")->fetchColumn() ?: 0,
        'views' => $db->query("SELECT SUM(views) FROM articles")->fetchColumn() ?: 0
    ];
    
    // آخر المحتويات
    $latestArticles = $db->query("
        SELECT * FROM articles 
        ORDER BY created_at DESC 
        LIMIT 5
    ")->fetchAll();
    
    $latestApps = $db->query("
        SELECT * FROM apps 
        ORDER BY created_at DESC 
        LIMIT 5
    ")->fetchAll();
    
} catch (Exception $e) {
    $stats = ['articles' => 0, 'apps' => 0, 'downloads' => 0, 'views' => 0];
    $latestArticles = [];
    $latestApps = [];
}

$message = '';
$messageType = 'success';

// معالجة حذف المقال
if (isset($_GET['delete_article'])) {
    try {
        $stmt = $db->prepare("DELETE FROM articles WHERE id = ?");
        $stmt->execute([$_GET['delete_article']]);
        $message = 'تم حذف المقال بنجاح';
        header("Refresh: 1; URL=index.php");
    } catch (Exception $e) {
        $message = 'حدث خطأ أثناء الحذف';
        $messageType = 'error';
    }
}

// معالجة حذف التطبيق
if (isset($_GET['delete_app'])) {
    try {
        // جلب مسار الملف
        $stmt = $db->prepare("SELECT file_path FROM apps WHERE id = ?");
        $stmt->execute([$_GET['delete_app']]);
        $app = $stmt->fetch();
        
        if ($app && file_exists('../' . $app['file_path'])) {
            unlink('../' . $app['file_path']);
        }
        
        $stmt = $db->prepare("DELETE FROM apps WHERE id = ?");
        $stmt->execute([$_GET['delete_app']]);
        $message = 'تم حذف التطبيق بنجاح';
        header("Refresh: 1; URL=index.php");
    } catch (Exception $e) {
        $message = 'حدث خطأ أثناء الحذف';
        $messageType = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم | DEV-OS</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        .admin-sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--bg-secondary);
            border-left: 1px solid var(--glass-border);
            z-index: 100;
            overflow-y: auto;
        }
        
        .admin-main {
            margin-right: 280px;
            min-height: 100vh;
            padding: 30px;
        }
        
        .admin-logo {
            padding: 30px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-nav {
            padding: 20px 0;
        }
        
        .admin-nav-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 30px;
            color: var(--text-secondary);
            transition: var(--transition);
            border-right: 3px solid transparent;
        }
        
        .admin-nav-item:hover,
        .admin-nav-item.active {
            background: var(--glass-bg);
            color: var(--text-primary);
            border-right-color: var(--neon-blue);
        }
        
        .admin-nav-item i {
            width: 24px;
            text-align: center;
            color: var(--neon-blue);
        }
        
        .admin-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-title {
            font-size: 28px;
            font-weight: 700;
        }
        
        .admin-actions {
            display: flex;
            gap: 15px;
        }
        
        .content-section {
            margin-bottom: 40px;
        }
        
        .section-header-flex {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 25px;
        }
        
        .section-header-flex h3 {
            font-size: 20px;
            font-weight: 600;
        }
        
        @media (max-width: 1024px) {
            .admin-sidebar {
                transform: translateX(100%);
                transition: transform 0.3s ease;
            }
            
            .admin-sidebar.active {
                transform: translateX(0);
            }
            
            .admin-main {
                margin-right: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <div class="admin-logo">
            <a href="../index.php" class="logo">
                <div class="logo-icon">D</div>
                <span class="logo-text">DEV-OS</span>
            </a>
        </div>
        
        <nav class="admin-nav">
            <a href="index.php" class="admin-nav-item active">
                <i class="fas fa-tachometer-alt"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="articles.php" class="admin-nav-item">
                <i class="fas fa-file-alt"></i>
                <span>المقالات</span>
            </a>
            <a href="apps.php" class="admin-nav-item">
                <i class="fas fa-mobile-alt"></i>
                <span>التطبيقات</span>
            </a>
            <a href="add-article.php" class="admin-nav-item">
                <i class="fas fa-plus-circle"></i>
                <span>إضافة مقال</span>
            </a>
            <a href="add-app.php" class="admin-nav-item">
                <i class="fas fa-upload"></i>
                <span>رفع تطبيق</span>
            </a>
            <a href="../index.php" class="admin-nav-item">
                <i class="fas fa-home"></i>
                <span>الموقع</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="admin-main">
        <div class="admin-header">
            <h1 class="admin-title">لوحة التحكم</h1>
            <div class="admin-actions">
                <a href="add-article.php" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i>
                    مقال جديد
                </a>
                <a href="add-app.php" class="btn btn-secondary btn-sm">
                    <i class="fas fa-upload"></i>
                    رفع تطبيق
                </a>
            </div>
        </div>
        
        <?php if ($message): ?>
            <?php echo showAlert($message, $messageType); ?>
        <?php endif; ?>
        
        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($stats['articles']); ?></div>
                <div class="stat-label">مقال</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($stats['apps']); ?></div>
                <div class="stat-label">تطبيق</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($stats['downloads']); ?></div>
                <div class="stat-label">تحميل</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($stats['views']); ?></div>
                <div class="stat-label">مشاهدة</div>
            </div>
        </div>
        
        <!-- Latest Articles -->
        <div class="content-section">
            <div class="section-header-flex">
                <h3><i class="fas fa-file-alt" style="color: var(--neon-blue); margin-left: 10px;"></i> آخر المقالات</h3>
                <a href="articles.php" class="btn btn-secondary btn-sm">عرض الكل</a>
            </div>
            
            <div class="glass-card" style="padding: 0; overflow: hidden;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>العنوان</th>
                            <th>القسم</th>
                            <th>الحالة</th>
                            <th>التاريخ</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($latestArticles as $article): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($article['title']); ?></td>
                            <td><?php echo htmlspecialchars($article['category']); ?></td>
                            <td>
                                <span style="color: <?php echo $article['status'] === 'published' ? 'var(--success)' : 'var(--warning)'; ?>">
                                    <?php echo $article['status'] === 'published' ? 'منشور' : 'مسودة'; ?>
                                </span>
                            </td>
                            <td><?php echo date('Y/m/d', strtotime($article['created_at'])); ?></td>
                            <td>
                                <div class="table-actions">
                                    <a href="edit-article.php?id=<?php echo $article['id']; ?>" class="table-action" title="تعديل">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?delete_article=<?php echo $article['id']; ?>" 
                                       class="table-action delete" 
                                       title="حذف"
                                       onclick="return confirm('هل أنت متأكد من الحذف؟')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Latest Apps -->
        <div class="content-section">
            <div class="section-header-flex">
                <h3><i class="fas fa-mobile-alt" style="color: var(--neon-blue); margin-left: 10px;"></i> آخر التطبيقات</h3>
                <a href="apps.php" class="btn btn-secondary btn-sm">عرض الكل</a>
            </div>
            
            <div class="glass-card" style="padding: 0; overflow: hidden;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>الاسم</th>
                            <th>الإصدار</th>
                            <th>الحجم</th>
                            <th>التحميلات</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($latestApps as $app): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($app['name']); ?></td>
                            <td><?php echo htmlspecialchars($app['version']); ?></td>
                            <td><?php echo formatFileSize($app['file_size']); ?></td>
                            <td><?php echo number_format($app['downloads']); ?></td>
                            <td>
                                <div class="table-actions">
                                    <a href="edit-app.php?id=<?php echo $app['id']; ?>" class="table-action" title="تعديل">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?delete_app=<?php echo $app['id']; ?>" 
                                       class="table-action delete" 
                                       title="حذف"
                                       onclick="return confirm('هل أنت متأكد من الحذف؟')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html>
