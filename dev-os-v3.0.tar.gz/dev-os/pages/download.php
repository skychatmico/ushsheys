<?php
/**
 * DEV-OS Download Page
 * صفحة تحميل التطبيق
 */

require_once '../includes/config.php';

$slug = isset($_GET['slug']) ? cleanInput($_GET['slug']) : '';

if (empty($slug)) {
    redirect('store.php');
}

try {
    $db = getDB();
    
    // جلب التطبيق
    $stmt = $db->prepare("
        SELECT * FROM apps 
        WHERE slug = ? AND status = 'active'
    ");
    $stmt->execute([$slug]);
    $app = $stmt->fetch();
    
    if (!$app) {
        redirect('store.php');
    }
    
    // زيادة عدد التحميلات
    $db->prepare("UPDATE apps SET downloads = downloads + 1 WHERE id = ?")
       ->execute([$app['id']]);
    
    // إعادة التوجيه للملف
    $filePath = '../' . $app['file_path'];
    
    if (file_exists($filePath)) {
        // تحديث الصفحة ثم التحميل
        header('Refresh: 2; URL=' . $app['file_path']);
    }
    
} catch (Exception $e) {
    redirect('store.php');
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>جاري التحميل... | <?php echo htmlspecialchars($app['name']); ?></title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        .download-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px;
        }
        
        .download-card {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-lg);
            padding: 60px;
            text-align: center;
            max-width: 500px;
            width: 100%;
            backdrop-filter: blur(var(--blur-amount));
        }
        
        .download-icon {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, var(--neon-blue), var(--neon-purple));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 30px;
            font-size: 48px;
            animation: pulse-download 2s infinite;
        }
        
        @keyframes pulse-download {
            0%, 100% { 
                transform: scale(1);
                box-shadow: 0 0 0 0 rgba(0, 212, 255, 0.4);
            }
            50% { 
                transform: scale(1.05);
                box-shadow: 0 0 0 20px rgba(0, 212, 255, 0);
            }
        }
        
        .download-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 15px;
        }
        
        .download-app-name {
            font-size: 20px;
            color: var(--neon-blue);
            margin-bottom: 10px;
        }
        
        .download-meta {
            font-size: 14px;
            color: var(--text-muted);
            margin-bottom: 30px;
        }
        
        .progress-bar {
            width: 100%;
            height: 6px;
            background: var(--glass-bg);
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 20px;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--neon-blue), var(--neon-purple));
            border-radius: 3px;
            animation: progress 2s ease-in-out;
            width: 100%;
        }
        
        @keyframes progress {
            0% { width: 0; }
            100% { width: 100%; }
        }
        
        .download-status {
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .download-status i {
            color: var(--neon-blue);
            margin-left: 8px;
        }
        
        .manual-download {
            margin-top: 30px;
            padding-top: 30px;
            border-top: 1px solid var(--glass-border);
        }
        
        .manual-download p {
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <!-- خلفية الشبكة -->
    <div class="bg-grid"></div>
    
    <div class="download-page">
        <div class="download-card">
            <div class="download-icon">
                <i class="fas fa-download"></i>
            </div>
            
            <h1 class="download-title">جاري تحميل التطبيق</h1>
            <p class="download-app-name"><?php echo htmlspecialchars($app['name']); ?></p>
            <p class="download-meta">
                الإصدار <?php echo htmlspecialchars($app['version']); ?> • 
                <?php echo formatFileSize($app['file_size']); ?>
            </p>
            
            <div class="progress-bar">
                <div class="progress-fill"></div>
            </div>
            
            <p class="download-status">
                <i class="fas fa-spinner fa-spin"></i>
                جاري التحميل... إذا لم يبدأ التحميل تلقائياً، اضغط الزر أدناه
            </p>
            
            <div class="manual-download">
                <p>لم يبدأ التحميل؟</p>
                <a href="../<?php echo $app['file_path']; ?>" class="btn btn-primary" download>
                    <i class="fas fa-redo"></i>
                    تحميل يدوي
                </a>
            </div>
        </div>
    </div>
    
    <script>
        // إعادة التوجيه التلقائي بعد 3 ثواني إذا لم يحدث التحميل
        setTimeout(() => {
            window.location.href = 'app.php?slug=<?php echo $app['slug']; ?>';
        }, 5000);
    </script>
</body>
</html>
