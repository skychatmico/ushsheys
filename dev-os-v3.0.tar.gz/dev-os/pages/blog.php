<?php
/**
 * DEV-OS Blog Page
 * صفحة المدونة
 */

require_once '../includes/config.php';

try {
    $db = getDB();
    
    // جلب جميع المقالات المنشورة
    $articles = $db->query("
        SELECT * FROM articles 
        WHERE status = 'published' 
        ORDER BY created_at DESC
    ")->fetchAll();
    
    // جلب الأقسام
    $categories = $db->query("
        SELECT DISTINCT category FROM articles 
        WHERE status = 'published'
    ")->fetchAll(PDO::FETCH_COLUMN);
    
} catch (Exception $e) {
    $articles = [];
    $categories = [];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المدونة | DEV-OS</title>
    <meta name="description" content="مقالات تقنية متنوعة في عالم البرمجة والتطوير">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        .blog-hero {
            padding: 120px 30px 60px;
            text-align: center;
            background: linear-gradient(180deg, rgba(168, 85, 247, 0.05), transparent);
        }
        
        .blog-hero h1 {
            font-size: clamp(32px, 6vw, 48px);
            font-weight: 800;
            margin-bottom: 20px;
        }
        
        .blog-hero h1 span {
            background: linear-gradient(135deg, var(--neon-blue), var(--neon-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .blog-hero p {
            font-size: 18px;
            color: var(--text-secondary);
            max-width: 600px;
            margin: 0 auto;
        }
        
        .filters-bar {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 40px;
            padding: 0 30px;
        }
        
        .filter-btn {
            padding: 10px 25px;
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-xl);
            color: var(--text-secondary);
            font-size: 14px;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .filter-btn:hover,
        .filter-btn.active {
            background: rgba(0, 212, 255, 0.1);
            border-color: var(--neon-blue);
            color: var(--neon-blue);
        }
        
        .blog-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 30px;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 30px 60px;
        }
        
        .blog-card {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-lg);
            overflow: hidden;
            transition: var(--transition);
            backdrop-filter: blur(var(--blur-amount));
        }
        
        .blog-card:hover {
            transform: translateY(-10px);
            border-color: rgba(0, 212, 255, 0.3);
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.4), 0 0 40px rgba(0, 212, 255, 0.1);
        }
        
        .blog-card-image {
            height: 200px;
            background: linear-gradient(135deg, var(--neon-blue), var(--neon-purple));
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        
        .blog-card-image i {
            font-size: 64px;
            opacity: 0.3;
        }
        
        .blog-card-category {
            position: absolute;
            top: 15px;
            right: 15px;
            background: rgba(0, 0, 0, 0.7);
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            color: var(--neon-blue);
        }
        
        .blog-card-content {
            padding: 25px;
        }
        
        .blog-card-title {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 12px;
            line-height: 1.4;
        }
        
        .blog-card-title a:hover {
            color: var(--neon-blue);
        }
        
        .blog-card-excerpt {
            font-size: 14px;
            color: var(--text-secondary);
            line-height: 1.8;
            margin-bottom: 20px;
        }
        
        .blog-card-meta {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-top: 20px;
            border-top: 1px solid var(--glass-border);
        }
        
        .blog-card-author {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
            color: var(--text-secondary);
        }
        
        .blog-card-date {
            font-size: 12px;
            color: var(--text-muted);
        }
        
        .blog-card-views {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            color: var(--text-muted);
        }
    </style>
</head>
<body>
    <!-- خلفية الشبكة -->
    <div class="bg-grid"></div>
    <div class="floating-particles"></div>
    
    <!-- الهيدر -->
    <header class="main-header">
        <div class="header-content">
            <a href="../index.php" class="logo">
                <div class="logo-icon">D</div>
                <span class="logo-text">DEV-OS</span>
                <span class="version-badge">v3.0</span>
            </a>
            
            <nav class="header-nav">
                <a href="../index.php" class="nav-link">الرئيسية</a>
                <a href="store.php" class="nav-link">المتجر</a>
                <a href="blog.php" class="nav-link active">المدونة</a>
                <a href="../admin/index.php" class="nav-link">لوحة التحكم</a>
            </nav>
            
            <div style="display: flex; align-items: center; gap: 15px;">
                <div class="search-container">
                    <div class="search-lens">
                        <i class="fas fa-search"></i>
                    </div>
                    <div class="search-expand">
                        <div class="search-input-wrapper">
                            <input type="text" class="search-input" placeholder="ابحث عن مقالات...">
                            <button class="search-close">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="search-results"></div>
                </div>
                
                <button class="menu-toggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </div>
    </header>
    
    <!-- القائمة الجانبية -->
    <div class="drawer-overlay"></div>
    <aside class="side-drawer">
        <div class="drawer-header">
            <h3 class="drawer-title">القائمة</h3>
            <button class="drawer-close">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <nav class="drawer-nav">
            <a href="../index.php" class="drawer-nav-item">
                <i class="fas fa-home"></i>
                <span>الرئيسية</span>
            </a>
            <a href="store.php" class="drawer-nav-item">
                <i class="fas fa-store"></i>
                <span>المتجر</span>
            </a>
            <a href="blog.php" class="drawer-nav-item active">
                <i class="fas fa-blog"></i>
                <span>المدونة</span>
            </a>
            <a href="../admin/index.php" class="drawer-nav-item">
                <i class="fas fa-cog"></i>
                <span>لوحة التحكم</span>
            </a>
        </nav>
        <div class="drawer-footer">
            <div class="drawer-social">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-github"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-telegram"></i></a>
            </div>
        </div>
    </aside>
    
    <!-- المحتوى الرئيسي -->
    <main class="main-content">
        <section class="blog-hero">
            <h1>مدونة <span>DEV-OS</span></h1>
            <p>مقالات تقنية متنوعة في عالم البرمجة والتطوير</p>
        </section>
        
        <!-- الفلاتر -->
        <div class="filters-bar">
            <button class="filter-btn active" data-filter="all">الكل</button>
            <?php foreach ($categories as $category): ?>
            <button class="filter-btn" data-filter="<?php echo htmlspecialchars($category); ?>">
                <?php echo htmlspecialchars($category); ?>
            </button>
            <?php endforeach; ?>
        </div>
        
        <!-- شبكة المقالات -->
        <div class="blog-grid">
            <?php foreach ($articles as $index => $article): ?>
            <article class="blog-card fade-in" data-category="<?php echo htmlspecialchars($article['category']); ?>">
                <div class="blog-card-image">
                    <i class="fas fa-code"></i>
                    <span class="blog-card-category"><?php echo htmlspecialchars($article['category']); ?></span>
                </div>
                <div class="blog-card-content">
                    <h3 class="blog-card-title">
                        <a href="article.php?slug=<?php echo $article['slug']; ?>">
                            <?php echo htmlspecialchars($article['title']); ?>
                        </a>
                    </h3>
                    <p class="blog-card-excerpt">
                        <?php echo excerpt($article['excerpt'] ?: $article['content'], 120); ?>
                    </p>
                    <div class="blog-card-meta">
                        <span class="blog-card-author">
                            <i class="fas fa-user"></i>
                            <?php echo htmlspecialchars($article['author']); ?>
                        </span>
                        <div style="display: flex; gap: 15px;">
                            <span class="blog-card-views">
                                <i class="fas fa-eye"></i>
                                <?php echo number_format($article['views']); ?>
                            </span>
                            <span class="blog-card-date">
                                <?php echo date('Y/m/d', strtotime($article['created_at'])); ?>
                            </span>
                        </div>
                    </div>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
        
        <?php if (empty($articles)): ?>
        <div class="empty-state">
            <i class="fas fa-pen-fancy"></i>
            <h3>لا توجد مقالات حالياً</h3>
            <p>سيتم إضافة مقالات جديدة قريباً</p>
        </div>
        <?php endif; ?>
    </main>
    
    <!-- الفوتر -->
    <footer class="main-footer">
        <div class="footer-content">
            <div class="footer-section">
                <h4>DEV-OS</h4>
                <p>نظام تشغيل رقمي متكامل للمطورين.</p>
            </div>
            <div class="footer-section">
                <h4>روابط سريعة</h4>
                <ul class="footer-links">
                    <li><a href="../index.php">الرئيسية</a></li>
                    <li><a href="store.php">المتجر</a></li>
                    <li><a href="blog.php">المدونة</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> DEV-OS. جميع الحقوق محفوظة.</p>
        </div>
    </footer>
    
    <!-- Scripts -->
    <script src="../js/main.js"></script>
    <script>
        // فلترة المقالات
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const filter = this.dataset.filter;
                
                // تحديث الأزرار النشطة
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                // فلترة البطاقات
                document.querySelectorAll('.blog-card').forEach(card => {
                    if (filter === 'all' || card.dataset.category === filter) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    </script>
</body>
</html>
