<?php
/**
 * DEV-OS Apps Management
 * إدارة التطبيقات
 */

require_once '../includes/config.php';

try {
    $db = getDB();
    
    // جلب جميع التطبيقات
    $apps = $db->query("
        SELECT * FROM apps 
        ORDER BY created_at DESC
    ")->fetchAll();
    
} catch (Exception $e) {
    $apps = [];
}

// معالجة الحذف
if (isset($_GET['delete'])) {
    try {
        // جلب مسار الملف
        $stmt = $db->prepare("SELECT file_path FROM apps WHERE id = ?");
        $stmt->execute([$_GET['delete']]);
        $app = $stmt->fetch();
        
        if ($app && file_exists('../' . $app['file_path'])) {
            unlink('../' . $app['file_path']);
        }
        
        $stmt = $db->prepare("DELETE FROM apps WHERE id = ?");
        $stmt->execute([$_GET['delete']]);
        header("Location: apps.php");
        exit;
    } catch (Exception $e) {
        $error = 'حدث خطأ أثناء الحذف';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة التطبيقات | DEV-OS</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        .admin-sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--bg-secondary);
            border-left: 1px solid var(--glass-border);
            z-index: 100;
            overflow-y: auto;
        }
        
        .admin-main {
            margin-right: 280px;
            min-height: 100vh;
            padding: 30px;
        }
        
        .admin-logo {
            padding: 30px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-nav {
            padding: 20px 0;
        }
        
        .admin-nav-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 30px;
            color: var(--text-secondary);
            transition: var(--transition);
            border-right: 3px solid transparent;
        }
        
        .admin-nav-item:hover,
        .admin-nav-item.active {
            background: var(--glass-bg);
            color: var(--text-primary);
            border-right-color: var(--neon-blue);
        }
        
        .admin-nav-item i {
            width: 24px;
            text-align: center;
            color: var(--neon-blue);
        }
        
        .admin-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-title {
            font-size: 28px;
            font-weight: 700;
        }
        
        @media (max-width: 1024px) {
            .admin-sidebar {
                transform: translateX(100%);
            }
            
            .admin-main {
                margin-right: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <div class="admin-logo">
            <a href="../index.php" class="logo">
                <div class="logo-icon">D</div>
                <span class="logo-text">DEV-OS</span>
            </a>
        </div>
        
        <nav class="admin-nav">
            <a href="index.php" class="admin-nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="articles.php" class="admin-nav-item">
                <i class="fas fa-file-alt"></i>
                <span>المقالات</span>
            </a>
            <a href="apps.php" class="admin-nav-item active">
                <i class="fas fa-mobile-alt"></i>
                <span>التطبيقات</span>
            </a>
            <a href="add-article.php" class="admin-nav-item">
                <i class="fas fa-plus-circle"></i>
                <span>إضافة مقال</span>
            </a>
            <a href="add-app.php" class="admin-nav-item">
                <i class="fas fa-upload"></i>
                <span>رفع تطبيق</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="admin-main">
        <div class="admin-header">
            <h1 class="admin-title">إدارة التطبيقات</h1>
            <a href="add-app.php" class="btn btn-primary btn-sm">
                <i class="fas fa-upload"></i>
                رفع تطبيق
            </a>
        </div>
        
        <div class="glass-card" style="padding: 0; overflow: hidden;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>الاسم</th>
                        <th>القسم</th>
                        <th>الإصدار</th>
                        <th>الحجم</th>
                        <th>التحميلات</th>
                        <th>الحالة</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($apps as $app): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($app['name']); ?></td>
                        <td><?php echo htmlspecialchars($app['category']); ?></td>
                        <td><?php echo htmlspecialchars($app['version']); ?></td>
                        <td><?php echo formatFileSize($app['file_size']); ?></td>
                        <td><?php echo number_format($app['downloads']); ?></td>
                        <td>
                            <span style="color: <?php echo $app['status'] === 'active' ? 'var(--success)' : 'var(--warning)'; ?>">
                                <?php echo $app['status'] === 'active' ? 'نشط' : 'غير نشط'; ?>
                            </span>
                        </td>
                        <td>
                            <div class="table-actions">
                                <a href="../pages/app.php?slug=<?php echo $app['slug']; ?>" class="table-action" title="عرض" target="_blank">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="edit-app.php?id=<?php echo $app['id']; ?>" class="table-action" title="تعديل">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="?delete=<?php echo $app['id']; ?>" 
                                   class="table-action delete" 
                                   title="حذف"
                                   onclick="return confirm('هل أنت متأكد من حذف هذا التطبيق؟')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <?php if (empty($apps)): ?>
        <div class="empty-state" style="margin-top: 40px;">
            <i class="fas fa-mobile-alt"></i>
            <h3>لا توجد تطبيقات</h3>
            <p>ارفع تطبيقك الأول الآن</p>
            <a href="add-app.php" class="btn btn-primary" style="margin-top: 20px;">
                <i class="fas fa-upload"></i>
                رفع تطبيق
            </a>
        </div>
        <?php endif; ?>
    </main>
</body>
</html>
