<?php
/**
 * DEV-OS Home Page
 * الصفحة الرئيسية لنظام التشغيل الرقمي
 */

require_once 'includes/config.php';

// جلب آخر المقالات
try {
    $db = getDB();
    
    $latestArticles = $db->query("
        SELECT * FROM articles 
        WHERE status = 'published' 
        ORDER BY created_at DESC 
        LIMIT 6
    ")->fetchAll();
    
    $latestApps = $db->query("
        SELECT * FROM apps 
        WHERE status = 'active' 
        ORDER BY created_at DESC 
        LIMIT 4
    ")->fetchAll();
    
} catch (Exception $e) {
    $latestArticles = [];
    $latestApps = [];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEV-OS v3.0 | نظام التشغيل الرقمي</title>
    <meta name="description" content="نظام تشغيل رقمي متكامل للمطورين - تطبيقات، مقالات، وأدوات برمجية">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;500;600&display=swap" rel="stylesheet">
    
    <!-- Styles -->
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        /* أنماط إضافية للصفحة الرئيسية */
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .feature-card {
            text-align: center;
            padding: 40px 30px;
        }
        
        .feature-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--neon-blue), var(--neon-purple));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            font-size: 28px;
            box-shadow: 0 10px 30px rgba(0, 212, 255, 0.3);
        }
        
        .feature-title {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 15px;
        }
        
        .feature-desc {
            font-size: 14px;
            color: var(--text-secondary);
            line-height: 1.8;
        }
        
        .cta-section {
            text-align: center;
            padding: 100px 30px;
            background: linear-gradient(180deg, transparent, rgba(0, 212, 255, 0.05), transparent);
        }
        
        .cta-title {
            font-size: clamp(24px, 4vw, 36px);
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        .cta-desc {
            font-size: 16px;
            color: var(--text-secondary);
            max-width: 600px;
            margin: 0 auto 40px;
        }
    </style>
</head>
<body>
    <!-- خلفية الشبكة -->
    <div class="bg-grid"></div>
    
    <!-- الجسيمات المتحركة -->
    <div class="floating-particles"></div>
    
    <!-- الهيدر -->
    <header class="main-header">
        <div class="header-content">
            <a href="index.php" class="logo">
                <div class="logo-icon">D</div>
                <span class="logo-text">DEV-OS</span>
                <span class="version-badge">v3.0</span>
            </a>
            
            <nav class="header-nav">
                <a href="index.php" class="nav-link active">الرئيسية</a>
                <a href="pages/store.php" class="nav-link">المتجر</a>
                <a href="pages/blog.php" class="nav-link">المدونة</a>
                <a href="admin/index.php" class="nav-link">لوحة التحكم</a>
            </nav>
            
            <div style="display: flex; align-items: center; gap: 15px;">
                <!-- نظام البحث -->
                <div class="search-container">
                    <div class="search-lens">
                        <i class="fas fa-search"></i>
                    </div>
                    <div class="search-expand">
                        <div class="search-input-wrapper">
                            <input type="text" class="search-input" placeholder="ابحث عن تطبيقات أو مقالات...">
                            <button class="search-close">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="search-results"></div>
                </div>
                
                <!-- زر القائمة -->
                <button class="menu-toggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </div>
    </header>
    
    <!-- القائمة الجانبية -->
    <div class="drawer-overlay"></div>
    <aside class="side-drawer">
        <div class="drawer-header">
            <h3 class="drawer-title">القائمة</h3>
            <button class="drawer-close">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <nav class="drawer-nav">
            <a href="index.php" class="drawer-nav-item active">
                <i class="fas fa-home"></i>
                <span>الرئيسية</span>
            </a>
            <a href="pages/store.php" class="drawer-nav-item">
                <i class="fas fa-store"></i>
                <span>المتجر</span>
            </a>
            <a href="pages/blog.php" class="drawer-nav-item">
                <i class="fas fa-blog"></i>
                <span>المدونة</span>
            </a>
            <a href="admin/index.php" class="drawer-nav-item">
                <i class="fas fa-cog"></i>
                <span>لوحة التحكم</span>
            </a>
        </nav>
        <div class="drawer-footer">
            <div class="drawer-social">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-github"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-telegram"></i></a>
            </div>
        </div>
    </aside>
    
    <!-- المحتوى الرئيسي -->
    <main class="main-content">
        <!-- قسم البطل -->
        <section class="hero-section">
            <div class="hero-content">
                <div class="hero-badge">
                    <span class="hero-badge-dot"></span>
                    <span class="hero-badge-text">نظام المحاكاة v3.0 متوفر الآن</span>
                </div>
                
                <h1 class="hero-title">
                    نظام تشغيل<br>
                    <span>رقمي متكامل</span>
                </h1>
                
                <p class="hero-description">
                    منصة شاملة للمطورين تجمع بين التطبيقات البرمجية، المقالات التقنية، 
                    والأدوات المتقدمة في بيئة زجاجية مستقبلية
                </p>
                
                <div class="hero-buttons">
                    <a href="pages/store.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-rocket"></i>
                        استكشف المتجر
                    </a>
                    <a href="pages/blog.php" class="btn btn-secondary btn-lg">
                        <i class="fas fa-book-open"></i>
                        تصفح المقالات
                    </a>
                </div>
            </div>
        </section>
        
        <!-- قسم المميزات -->
        <section class="section">
            <div class="section-header">
                <span class="section-label">المميزات</span>
                <h2 class="section-title">لماذا DEV-OS؟</h2>
                <p class="section-description">
                    منصة متكامله توفر كل ما يحتاجه المطور في مكان واحد
                </p>
            </div>
            
            <div class="features-grid">
                <div class="glass-card feature-card fade-in">
                    <div class="feature-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h3 class="feature-title">تطبيقات متنوعة</h3>
                    <p class="feature-desc">
                        مجموعة واسعة من التطبيقات البرمجية المخصصة للمطورين، من محررات الأكواد إلى أدوات إدارة قواعد البيانات
                    </p>
                </div>
                
                <div class="glass-card feature-card fade-in stagger-1">
                    <div class="feature-icon">
                        <i class="fas fa-book"></i>
                    </div>
                    <h3 class="feature-title">مقالات تقنية</h3>
                    <p class="feature-desc">
                        محتوى تعليمي عميق يغطي أحدث التقنيات ولغات البرمجة مع أمثلة عملية وشروحات مفصلة
                    </p>
                </div>
                
                <div class="glass-card feature-card fade-in stagger-2">
                    <div class="feature-icon">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <h3 class="feature-title">بحث فوري</h3>
                    <p class="feature-desc">
                        نظام بحث متقدم يوفر نتائج فورية من قاعدة البيانات مع اقتراحات ذكية أثناء الكتابة
                    </p>
                </div>
                
                <div class="glass-card feature-card fade-in stagger-3">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3 class="feature-title">أمان موثوق</h3>
                    <p class="feature-desc">
                        جميع التطبيقات يتم فحصها قبل النشر، ونستخدم PDO للتعامل الآمن مع قاعدة البيانات
                    </p>
                </div>
            </div>
        </section>
        
        <!-- قسم آخر التطبيقات -->
        <section class="section">
            <div class="section-header">
                <span class="section-label">المتجر</span>
                <h2 class="section-title">آخر التطبيقات</h2>
                <p class="section-description">
                    اكتشف أحدث التطبيقات المضافة إلى المنصة
                </p>
            </div>
            
            <div class="content-grid">
                <?php foreach ($latestApps as $index => $app): ?>
                <div class="glass-card app-card fade-in stagger-<?php echo $index % 4; ?>">
                    <div class="app-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h3 class="app-name"><?php echo htmlspecialchars($app['name']); ?></h3>
                    <p class="app-description">
                        <?php echo excerpt($app['description'], 100); ?>
                    </p>
                    <div class="app-meta">
                        <div class="app-meta-item">
                            <span class="app-meta-label">الإصدار</span>
                            <span class="app-meta-value"><?php echo htmlspecialchars($app['version']); ?></span>
                        </div>
                        <div class="app-meta-item">
                            <span class="app-meta-label">الحجم</span>
                            <span class="app-meta-value"><?php echo formatFileSize($app['file_size']); ?></span>
                        </div>
                    </div>
                    <a href="pages/app.php?slug=<?php echo $app['slug']; ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-download"></i>
                        تحميل
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div style="text-align: center; margin-top: 40px;">
                <a href="pages/store.php" class="btn btn-secondary">
                    عرض جميع التطبيقات
                    <i class="fas fa-arrow-left"></i>
                </a>
            </div>
        </section>
        
        <!-- قسم آخر المقالات -->
        <section class="section">
            <div class="section-header">
                <span class="section-label">المدونة</span>
                <h2 class="section-title">آخر المقالات</h2>
                <p class="section-description">
                    مقالات تقنية متنوعة في عالم البرمجة والتطوير
                </p>
            </div>
            
            <div class="content-grid">
                <?php foreach ($latestArticles as $index => $article): ?>
                <article class="glass-card article-card fade-in stagger-<?php echo $index % 4; ?>">
                    <?php if ($article['featured_image']): ?>
                    <img src="<?php echo htmlspecialchars($article['featured_image']); ?>" 
                         alt="<?php echo htmlspecialchars($article['title']); ?>" 
                         class="article-image">
                    <?php else: ?>
                    <div class="article-image" style="background: linear-gradient(135deg, var(--neon-blue), var(--neon-purple)); display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-code" style="font-size: 48px; opacity: 0.5;"></i>
                    </div>
                    <?php endif; ?>
                    
                    <span class="article-category"><?php echo htmlspecialchars($article['category']); ?></span>
                    <h3 class="article-title">
                        <a href="pages/article.php?slug=<?php echo $article['slug']; ?>">
                            <?php echo htmlspecialchars($article['title']); ?>
                        </a>
                    </h3>
                    <p class="article-excerpt">
                        <?php echo excerpt($article['excerpt'] ?: $article['content'], 120); ?>
                    </p>
                    <div class="article-meta">
                        <span class="article-author">
                            <i class="fas fa-user"></i>
                            <?php echo htmlspecialchars($article['author']); ?>
                        </span>
                        <span class="article-date">
                            <?php echo date('Y/m/d', strtotime($article['created_at'])); ?>
                        </span>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
            
            <div style="text-align: center; margin-top: 40px;">
                <a href="pages/blog.php" class="btn btn-secondary">
                    عرض جميع المقالات
                    <i class="fas fa-arrow-left"></i>
                </a>
            </div>
        </section>
        
        <!-- قسم الدعوة للعمل -->
        <section class="cta-section">
            <h2 class="cta-title">جاهز للبدء؟</h2>
            <p class="cta-desc">
                انضم إلى آلاف المطورين الذين يستخدمون DEV-OS يومياً للوصول إلى التطبيقات والأدوات التي يحتاجونها
            </p>
            <a href="pages/store.php" class="btn btn-primary btn-lg">
                <i class="fas fa-rocket"></i>
                ابدأ الآن
            </a>
        </section>
    </main>
    
    <!-- الفوتر -->
    <footer class="main-footer">
        <div class="footer-content">
            <div class="footer-section">
                <h4>DEV-OS</h4>
                <p>
                    نظام تشغيل رقمي متكامل للمطورين، يوفر تطبيقات، مقالات، وأدوات برمجية في بيئة حديثة ومستقبلية.
                </p>
            </div>
            <div class="footer-section">
                <h4>روابط سريعة</h4>
                <ul class="footer-links">
                    <li><a href="index.php">الرئيسية</a></li>
                    <li><a href="pages/store.php">المتجر</a></li>
                    <li><a href="pages/blog.php">المدونة</a></li>
                    <li><a href="admin/index.php">لوحة التحكم</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>تواصل معنا</h4>
                <ul class="footer-links">
                    <li><a href="#"><i class="fab fa-twitter"></i> تويتر</a></li>
                    <li><a href="#"><i class="fab fa-github"></i> جيثب</a></li>
                    <li><a href="#"><i class="fab fa-discord"></i> ديسكورد</a></li>
                    <li><a href="#"><i class="fas fa-envelope"></i> البريد</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> DEV-OS. جميع الحقوق محفوظة.</p>
        </div>
    </footer>
    
    <!-- Scripts -->
    <script src="js/main.js"></script>
</body>
</html>
