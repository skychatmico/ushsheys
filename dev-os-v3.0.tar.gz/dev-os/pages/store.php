<?php
/**
 * DEV-OS Store Page
 * صفحة المتجر
 */

require_once '../includes/config.php';

try {
    $db = getDB();
    
    // جلب جميع التطبيقات
    $apps = $db->query("
        SELECT * FROM apps 
        WHERE status = 'active' 
        ORDER BY downloads DESC
    ")->fetchAll();
    
    // جلب الأقسام
    $categories = $db->query("
        SELECT DISTINCT category FROM apps 
        WHERE status = 'active'
    ")->fetchAll(PDO::FETCH_COLUMN);
    
} catch (Exception $e) {
    $apps = [];
    $categories = [];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المتجر | DEV-OS</title>
    <meta name="description" content="تصفح وحمّل أحدث التطبيقات البرمجية للمطورين">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        .store-hero {
            padding: 120px 30px 60px;
            text-align: center;
            background: linear-gradient(180deg, rgba(0, 212, 255, 0.05), transparent);
        }
        
        .store-hero h1 {
            font-size: clamp(32px, 6vw, 48px);
            font-weight: 800;
            margin-bottom: 20px;
        }
        
        .store-hero h1 span {
            background: linear-gradient(135deg, var(--neon-blue), var(--neon-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .store-hero p {
            font-size: 18px;
            color: var(--text-secondary);
            max-width: 600px;
            margin: 0 auto;
        }
        
        .filters-bar {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 40px;
            padding: 0 30px;
        }
        
        .filter-btn {
            padding: 10px 25px;
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-xl);
            color: var(--text-secondary);
            font-size: 14px;
            cursor: pointer;
            transition: var(--transition);
        }
        
        .filter-btn:hover,
        .filter-btn.active {
            background: rgba(0, 212, 255, 0.1);
            border-color: var(--neon-blue);
            color: var(--neon-blue);
        }
        
        .apps-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 30px 60px;
        }
        
        .app-card-large {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-lg);
            padding: 35px;
            text-align: center;
            transition: var(--transition);
            backdrop-filter: blur(var(--blur-amount));
        }
        
        .app-card-large:hover {
            transform: translateY(-10px);
            border-color: rgba(0, 212, 255, 0.3);
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.4), 0 0 40px rgba(0, 212, 255, 0.1);
        }
        
        .app-icon-large {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, var(--neon-blue), var(--neon-purple));
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            font-size: 48px;
            box-shadow: 0 15px 40px rgba(0, 212, 255, 0.3);
        }
        
        .app-category-tag {
            display: inline-block;
            font-size: 11px;
            color: var(--neon-blue);
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 15px;
        }
        
        .app-name-large {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 15px;
        }
        
        .app-desc-large {
            font-size: 14px;
            color: var(--text-secondary);
            line-height: 1.8;
            margin-bottom: 25px;
        }
        
        .app-stats {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-bottom: 25px;
            padding: 20px 0;
            border-top: 1px solid var(--glass-border);
            border-bottom: 1px solid var(--glass-border);
        }
        
        .app-stat {
            text-align: center;
        }
        
        .app-stat-value {
            font-size: 20px;
            font-weight: 700;
            color: var(--neon-blue);
        }
        
        .app-stat-label {
            font-size: 12px;
            color: var(--text-muted);
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <!-- خلفية الشبكة -->
    <div class="bg-grid"></div>
    <div class="floating-particles"></div>
    
    <!-- الهيدر -->
    <header class="main-header">
        <div class="header-content">
            <a href="../index.php" class="logo">
                <div class="logo-icon">D</div>
                <span class="logo-text">DEV-OS</span>
                <span class="version-badge">v3.0</span>
            </a>
            
            <nav class="header-nav">
                <a href="../index.php" class="nav-link">الرئيسية</a>
                <a href="store.php" class="nav-link active">المتجر</a>
                <a href="blog.php" class="nav-link">المدونة</a>
                <a href="../admin/index.php" class="nav-link">لوحة التحكم</a>
            </nav>
            
            <div style="display: flex; align-items: center; gap: 15px;">
                <div class="search-container">
                    <div class="search-lens">
                        <i class="fas fa-search"></i>
                    </div>
                    <div class="search-expand">
                        <div class="search-input-wrapper">
                            <input type="text" class="search-input" placeholder="ابحث عن تطبيقات...">
                            <button class="search-close">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="search-results"></div>
                </div>
                
                <button class="menu-toggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </div>
    </header>
    
    <!-- القائمة الجانبية -->
    <div class="drawer-overlay"></div>
    <aside class="side-drawer">
        <div class="drawer-header">
            <h3 class="drawer-title">القائمة</h3>
            <button class="drawer-close">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <nav class="drawer-nav">
            <a href="../index.php" class="drawer-nav-item">
                <i class="fas fa-home"></i>
                <span>الرئيسية</span>
            </a>
            <a href="store.php" class="drawer-nav-item active">
                <i class="fas fa-store"></i>
                <span>المتجر</span>
            </a>
            <a href="blog.php" class="drawer-nav-item">
                <i class="fas fa-blog"></i>
                <span>المدونة</span>
            </a>
            <a href="../admin/index.php" class="drawer-nav-item">
                <i class="fas fa-cog"></i>
                <span>لوحة التحكم</span>
            </a>
        </nav>
        <div class="drawer-footer">
            <div class="drawer-social">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-github"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-telegram"></i></a>
            </div>
        </div>
    </aside>
    
    <!-- المحتوى الرئيسي -->
    <main class="main-content">
        <section class="store-hero">
            <h1>متجر <span>DEV-OS</span></h1>
            <p>اكتشف مجموعتنا المختارة من التطبيقات البرمجية المصممة خصيصاً للمطورين</p>
        </section>
        
        <!-- الفلاتر -->
        <div class="filters-bar">
            <button class="filter-btn active" data-filter="all">الكل</button>
            <?php foreach ($categories as $category): ?>
            <button class="filter-btn" data-filter="<?php echo htmlspecialchars($category); ?>">
                <?php echo htmlspecialchars($category); ?>
            </button>
            <?php endforeach; ?>
        </div>
        
        <!-- شبكة التطبيقات -->
        <div class="apps-grid">
            <?php foreach ($apps as $index => $app): ?>
            <div class="app-card-large fade-in" data-category="<?php echo htmlspecialchars($app['category']); ?>">
                <div class="app-icon-large">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <span class="app-category-tag"><?php echo htmlspecialchars($app['category']); ?></span>
                <h3 class="app-name-large"><?php echo htmlspecialchars($app['name']); ?></h3>
                <p class="app-desc-large">
                    <?php echo excerpt($app['description'], 120); ?>
                </p>
                <div class="app-stats">
                    <div class="app-stat">
                        <div class="app-stat-value"><?php echo htmlspecialchars($app['version']); ?></div>
                        <div class="app-stat-label">الإصدار</div>
                    </div>
                    <div class="app-stat">
                        <div class="app-stat-value"><?php echo formatFileSize($app['file_size']); ?></div>
                        <div class="app-stat-label">الحجم</div>
                    </div>
                    <div class="app-stat">
                        <div class="app-stat-value"><?php echo number_format($app['downloads']); ?></div>
                        <div class="app-stat-label">تحميل</div>
                    </div>
                </div>
                <a href="app.php?slug=<?php echo $app['slug']; ?>" class="btn btn-primary">
                    <i class="fas fa-download"></i>
                    تحميل التطبيق
                </a>
            </div>
            <?php endforeach; ?>
        </div>
        
        <?php if (empty($apps)): ?>
        <div class="empty-state">
            <i class="fas fa-box-open"></i>
            <h3>لا توجد تطبيقات حالياً</h3>
            <p>سيتم إضافة تطبيقات جديدة قريباً</p>
        </div>
        <?php endif; ?>
    </main>
    
    <!-- الفوتر -->
    <footer class="main-footer">
        <div class="footer-content">
            <div class="footer-section">
                <h4>DEV-OS</h4>
                <p>نظام تشغيل رقمي متكامل للمطورين.</p>
            </div>
            <div class="footer-section">
                <h4>روابط سريعة</h4>
                <ul class="footer-links">
                    <li><a href="../index.php">الرئيسية</a></li>
                    <li><a href="store.php">المتجر</a></li>
                    <li><a href="blog.php">المدونة</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> DEV-OS. جميع الحقوق محفوظة.</p>
        </div>
    </footer>
    
    <!-- Scripts -->
    <script src="../js/main.js"></script>
    <script>
        // فلترة التطبيقات
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const filter = this.dataset.filter;
                
                // تحديث الأزرار النشطة
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                // فلترة البطاقات
                document.querySelectorAll('.app-card-large').forEach(card => {
                    if (filter === 'all' || card.dataset.category === filter) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    </script>
</body>
</html>
