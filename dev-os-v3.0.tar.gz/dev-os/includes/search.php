<?php
/**
 * DEV-OS Search System
 * نظام البحث الفوري
 */

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

// التحقق من وجود استعلام البحث
$query = isset($_GET['q']) ? cleanInput($_GET['q']) : '';

if (empty($query) || strlen($query) < 2) {
    echo json_encode([]);
    exit;
}

try {
    $db = getDB();
    $results = [];
    $searchTerm = "%{$query}%";
    
    // البحث في المقالات
    $articleStmt = $db->prepare("
        SELECT id, title, slug, excerpt, 'article' as type 
        FROM articles 
        WHERE (title LIKE :query OR content LIKE :query OR tags LIKE :query)
        AND status = 'published'
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $articleStmt->execute([':query' => $searchTerm]);
    $articles = $articleStmt->fetchAll();
    
    foreach ($articles as $article) {
        $results[] = [
            'id' => $article['id'],
            'title' => $article['title'],
            'slug' => $article['slug'],
            'excerpt' => excerpt($article['excerpt'] ?: '', 80),
            'type' => 'article'
        ];
    }
    
    // البحث في التطبيقات
    $appStmt = $db->prepare("
        SELECT id, name, slug, description as excerpt, 'app' as type 
        FROM apps 
        WHERE (name LIKE :query OR description LIKE :query OR category LIKE :query)
        AND status = 'active'
        ORDER BY downloads DESC
        LIMIT 5
    ");
    $appStmt->execute([':query' => $searchTerm]);
    $apps = $appStmt->fetchAll();
    
    foreach ($apps as $app) {
        $results[] = [
            'id' => $app['id'],
            'title' => $app['name'],
            'slug' => $app['slug'],
            'excerpt' => excerpt($app['excerpt'] ?: '', 80),
            'type' => 'app'
        ];
    }
    
    // ترتيب النتائج حسب الصلة (يمكن تحسينها لاحقاً)
    echo json_encode($results);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'حدث خطأ في البحث']);
}
?>
