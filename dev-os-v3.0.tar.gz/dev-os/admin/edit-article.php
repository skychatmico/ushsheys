<?php
/**
 * DEV-OS Edit Article
 * تعديل مقال
 */

require_once '../includes/config.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id === 0) {
    redirect('articles.php');
}

try {
    $db = getDB();
    
    // جلب المقال
    $stmt = $db->prepare("SELECT * FROM articles WHERE id = ?");
    $stmt->execute([$id]);
    $article = $stmt->fetch();
    
    if (!$article) {
        redirect('articles.php');
    }
    
} catch (Exception $e) {
    redirect('articles.php');
}

$message = '';
$messageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $title = cleanInput($_POST['title']);
        $content = $_POST['content'];
        $excerpt = cleanInput($_POST['excerpt']);
        $category = cleanInput($_POST['category']);
        $tags = cleanInput($_POST['tags']);
        $author = cleanInput($_POST['author']);
        $status = $_POST['status'];
        
        if (empty($title) || empty($content)) {
            throw new Exception('العنوان والمحتوى مطلوبان');
        }
        
        $stmt = $db->prepare("
            UPDATE articles 
            SET title = ?, content = ?, excerpt = ?, category = ?, tags = ?, author = ?, status = ?
            WHERE id = ?
        ");
        
        $stmt->execute([$title, $content, $excerpt, $category, $tags, $author, $status, $id]);
        
        $message = 'تم تحديث المقال بنجاح!';
        
        // تحديث البيانات المعروضة
        $article['title'] = $title;
        $article['content'] = $content;
        $article['excerpt'] = $excerpt;
        $article['category'] = $category;
        $article['tags'] = $tags;
        $article['author'] = $author;
        $article['status'] = $status;
        
    } catch (Exception $e) {
        $message = $e->getMessage();
        $messageType = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل مقال | DEV-OS</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        .admin-sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--bg-secondary);
            border-left: 1px solid var(--glass-border);
            z-index: 100;
            overflow-y: auto;
        }
        
        .admin-main {
            margin-right: 280px;
            min-height: 100vh;
            padding: 30px;
        }
        
        .admin-logo {
            padding: 30px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-nav {
            padding: 20px 0;
        }
        
        .admin-nav-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 30px;
            color: var(--text-secondary);
            transition: var(--transition);
            border-right: 3px solid transparent;
        }
        
        .admin-nav-item:hover,
        .admin-nav-item.active {
            background: var(--glass-bg);
            color: var(--text-primary);
            border-right-color: var(--neon-blue);
        }
        
        .admin-nav-item i {
            width: 24px;
            text-align: center;
            color: var(--neon-blue);
        }
        
        .admin-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-title {
            font-size: 28px;
            font-weight: 700;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }
        
        .form-grid .form-group.full-width {
            grid-column: 1 / -1;
        }
        
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .admin-main {
                margin-right: 0;
            }
            
            .admin-sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <div class="admin-logo">
            <a href="../index.php" class="logo">
                <div class="logo-icon">D</div>
                <span class="logo-text">DEV-OS</span>
            </a>
        </div>
        
        <nav class="admin-nav">
            <a href="index.php" class="admin-nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="articles.php" class="admin-nav-item active">
                <i class="fas fa-file-alt"></i>
                <span>المقالات</span>
            </a>
            <a href="apps.php" class="admin-nav-item">
                <i class="fas fa-mobile-alt"></i>
                <span>التطبيقات</span>
            </a>
            <a href="add-article.php" class="admin-nav-item">
                <i class="fas fa-plus-circle"></i>
                <span>إضافة مقال</span>
            </a>
            <a href="add-app.php" class="admin-nav-item">
                <i class="fas fa-upload"></i>
                <span>رفع تطبيق</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="admin-main">
        <div class="admin-header">
            <h1 class="admin-title">تعديل مقال</h1>
            <a href="articles.php" class="btn btn-secondary btn-sm">
                <i class="fas fa-arrow-right"></i>
                العودة
            </a>
        </div>
        
        <?php if ($message): ?>
            <?php echo showAlert($message, $messageType); ?>
        <?php endif; ?>
        
        <div class="glass-card">
            <form method="POST" action="">
                <div class="form-grid">
                    <div class="form-group full-width">
                        <label class="form-label">عنوان المقال</label>
                        <input type="text" name="title" class="form-input" 
                               value="<?php echo htmlspecialchars($article['title']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">القسم</label>
                        <select name="category" class="form-select">
                            <option value="برمجة" <?php echo $article['category'] === 'برمجة' ? 'selected' : ''; ?>>برمجة</option>
                            <option value="ويب" <?php echo $article['category'] === 'ويب' ? 'selected' : ''; ?>>ويب</option>
                            <option value="موبايل" <?php echo $article['category'] === 'موبايل' ? 'selected' : ''; ?>>موبايل</option>
                            <option value="قواعد بيانات" <?php echo $article['category'] === 'قواعد بيانات' ? 'selected' : ''; ?>>قواعد بيانات</option>
                            <option value="أمن" <?php echo $article['category'] === 'أمن' ? 'selected' : ''; ?>>أمن</option>
                            <option value="أدوات" <?php echo $article['category'] === 'أدوات' ? 'selected' : ''; ?>>أدوات</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">الحالة</label>
                        <select name="status" class="form-select">
                            <option value="published" <?php echo $article['status'] === 'published' ? 'selected' : ''; ?>>منشور</option>
                            <option value="draft" <?php echo $article['status'] === 'draft' ? 'selected' : ''; ?>>مسودة</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">الوسوم (مفصولة بفواصل)</label>
                        <input type="text" name="tags" class="form-input" 
                               value="<?php echo htmlspecialchars($article['tags']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">الكاتب</label>
                        <input type="text" name="author" class="form-input" 
                               value="<?php echo htmlspecialchars($article['author']); ?>">
                    </div>
                    
                    <div class="form-group full-width">
                        <label class="form-label">ملخص المقال</label>
                        <textarea name="excerpt" class="form-textarea" rows="3"><?php echo htmlspecialchars($article['excerpt']); ?></textarea>
                    </div>
                    
                    <div class="form-group full-width">
                        <label class="form-label">محتوى المقال (يدعم HTML)</label>
                        <textarea name="content" class="form-textarea" rows="15" required><?php echo htmlspecialchars($article['content']); ?></textarea>
                    </div>
                    
                    <div class="form-group full-width">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i>
                            حفظ التغييرات
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>
</body>
</html>
