<?php
/**
 * DEV-OS Single Article Page
 * صفحة عرض المقال
 */

require_once '../includes/config.php';

$slug = isset($_GET['slug']) ? cleanInput($_GET['slug']) : '';

if (empty($slug)) {
    redirect('blog.php');
}

try {
    $db = getDB();
    
    // جلب المقال
    $stmt = $db->prepare("
        SELECT * FROM articles 
        WHERE slug = ? AND status = 'published'
    ");
    $stmt->execute([$slug]);
    $article = $stmt->fetch();
    
    if (!$article) {
        redirect('blog.php');
    }
    
    // زيادة عدد المشاهدات
    $db->prepare("UPDATE articles SET views = views + 1 WHERE id = ?")
       ->execute([$article['id']]);
    
    // جلب مقالات ذات صلة
    $related = $db->prepare("
        SELECT * FROM articles 
        WHERE category = ? AND id != ? AND status = 'published'
        ORDER BY created_at DESC
        LIMIT 3
    ");
    $related->execute([$article['category'], $article['id']]);
    $relatedArticles = $related->fetchAll();
    
} catch (Exception $e) {
    redirect('blog.php');
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($article['title']); ?> | DEV-OS</title>
    <meta name="description" content="<?php echo excerpt($article['excerpt'] ?: $article['content'], 150); ?>">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        .article-page {
            max-width: 900px;
            margin: 0 auto;
            padding: 120px 30px 60px;
        }
        
        .article-header {
            text-align: center;
            margin-bottom: 50px;
            padding-bottom: 40px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .article-category {
            display: inline-block;
            font-size: 12px;
            font-weight: 600;
            color: var(--neon-blue);
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 20px;
            padding: 8px 20px;
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
        }
        
        .article-title {
            font-size: clamp(28px, 5vw, 42px);
            font-weight: 700;
            margin-bottom: 30px;
            line-height: 1.3;
        }
        
        .article-meta {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
        }
        
        .article-meta-item {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .article-meta-item i {
            color: var(--neon-blue);
        }
        
        .article-content {
            font-size: 17px;
            line-height: 2;
            color: var(--text-secondary);
        }
        
        .article-content h2 {
            font-size: 28px;
            font-weight: 700;
            color: var(--text-primary);
            margin: 50px 0 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .article-content h3 {
            font-size: 22px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 35px 0 20px;
        }
        
        .article-content p {
            margin-bottom: 25px;
        }
        
        .article-content ul,
        .article-content ol {
            margin-bottom: 25px;
            padding-right: 30px;
        }
        
        .article-content li {
            margin-bottom: 12px;
        }
        
        .article-content pre {
            background: #0d1117;
            border: 1px solid #30363d;
            border-radius: var(--radius-md);
            padding: 25px;
            overflow-x: auto;
            margin: 30px 0;
            direction: ltr;
            text-align: left;
        }
        
        .article-content code {
            font-family: 'Fira Code', 'Consolas', monospace;
            font-size: 14px;
            color: #e6edf3;
        }
        
        .article-content :not(pre) > code {
            background: var(--glass-bg);
            padding: 3px 10px;
            border-radius: 5px;
            color: var(--neon-blue);
        }
        
        .article-tags {
            margin-top: 50px;
            padding-top: 30px;
            border-top: 1px solid var(--glass-border);
        }
        
        .article-tags-label {
            font-size: 14px;
            color: var(--text-muted);
            margin-bottom: 15px;
        }
        
        .article-tags-list {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .article-tag {
            padding: 8px 18px;
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            font-size: 13px;
            color: var(--text-secondary);
            transition: var(--transition);
        }
        
        .article-tag:hover {
            border-color: var(--neon-blue);
            color: var(--neon-blue);
        }
        
        .related-section {
            margin-top: 80px;
            padding-top: 50px;
            border-top: 1px solid var(--glass-border);
        }
        
        .related-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .related-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
        }
        
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 30px;
            color: var(--text-secondary);
            transition: var(--transition);
        }
        
        .back-link:hover {
            color: var(--neon-blue);
        }
    </style>
</head>
<body>
    <!-- خلفية الشبكة -->
    <div class="bg-grid"></div>
    <div class="floating-particles"></div>
    
    <!-- الهيدر -->
    <header class="main-header">
        <div class="header-content">
            <a href="../index.php" class="logo">
                <div class="logo-icon">D</div>
                <span class="logo-text">DEV-OS</span>
                <span class="version-badge">v3.0</span>
            </a>
            
            <nav class="header-nav">
                <a href="../index.php" class="nav-link">الرئيسية</a>
                <a href="store.php" class="nav-link">المتجر</a>
                <a href="blog.php" class="nav-link active">المدونة</a>
                <a href="../admin/index.php" class="nav-link">لوحة التحكم</a>
            </nav>
            
            <div style="display: flex; align-items: center; gap: 15px;">
                <div class="search-container">
                    <div class="search-lens">
                        <i class="fas fa-search"></i>
                    </div>
                    <div class="search-expand">
                        <div class="search-input-wrapper">
                            <input type="text" class="search-input" placeholder="ابحث...">
                            <button class="search-close">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="search-results"></div>
                </div>
                
                <button class="menu-toggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </div>
    </header>
    
    <!-- القائمة الجانبية -->
    <div class="drawer-overlay"></div>
    <aside class="side-drawer">
        <div class="drawer-header">
            <h3 class="drawer-title">القائمة</h3>
            <button class="drawer-close">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <nav class="drawer-nav">
            <a href="../index.php" class="drawer-nav-item">
                <i class="fas fa-home"></i>
                <span>الرئيسية</span>
            </a>
            <a href="store.php" class="drawer-nav-item">
                <i class="fas fa-store"></i>
                <span>المتجر</span>
            </a>
            <a href="blog.php" class="drawer-nav-item active">
                <i class="fas fa-blog"></i>
                <span>المدونة</span>
            </a>
            <a href="../admin/index.php" class="drawer-nav-item">
                <i class="fas fa-cog"></i>
                <span>لوحة التحكم</span>
            </a>
        </nav>
    </aside>
    
    <!-- المحتوى الرئيسي -->
    <main class="main-content">
        <article class="article-page">
            <a href="blog.php" class="back-link">
                <i class="fas fa-arrow-right"></i>
                العودة للمدونة
            </a>
            
            <header class="article-header">
                <span class="article-category"><?php echo htmlspecialchars($article['category']); ?></span>
                <h1 class="article-title"><?php echo htmlspecialchars($article['title']); ?></h1>
                <div class="article-meta">
                    <span class="article-meta-item">
                        <i class="fas fa-user"></i>
                        <?php echo htmlspecialchars($article['author']); ?>
                    </span>
                    <span class="article-meta-item">
                        <i class="fas fa-calendar"></i>
                        <?php echo date('Y/m/d', strtotime($article['created_at'])); ?>
                    </span>
                    <span class="article-meta-item">
                        <i class="fas fa-eye"></i>
                        <?php echo number_format($article['views'] + 1); ?> مشاهدة
                    </span>
                </div>
            </header>
            
            <div class="article-content">
                <?php echo $article['content']; ?>
            </div>
            
            <?php if ($article['tags']): ?>
            <div class="article-tags">
                <div class="article-tags-label">الوسوم:</div>
                <div class="article-tags-list">
                    <?php foreach (explode(',', $article['tags']) as $tag): ?>
                    <span class="article-tag"><?php echo htmlspecialchars(trim($tag)); ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </article>
        
        <!-- مقالات ذات صلة -->
        <?php if (!empty($relatedArticles)): ?>
        <section class="related-section" style="max-width: 900px; margin: 80px auto; padding: 0 30px;">
            <h2 class="related-title">مقالات ذات صلة</h2>
            <div class="related-grid">
                <?php foreach ($relatedArticles as $related): ?>
                <a href="article.php?slug=<?php echo $related['slug']; ?>" class="glass-card" style="text-decoration: none;">
                    <span style="font-size: 12px; color: var(--neon-blue); margin-bottom: 10px; display: block;">
                        <?php echo htmlspecialchars($related['category']); ?>
                    </span>
                    <h4 style="font-size: 16px; margin-bottom: 10px;">
                        <?php echo htmlspecialchars($related['title']); ?>
                    </h4>
                    <p style="font-size: 13px; color: var(--text-muted);">
                        <?php echo excerpt($related['excerpt'] ?: $related['content'], 80); ?>
                    </p>
                </a>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>
    </main>
    
    <!-- الفوتر -->
    <footer class="main-footer">
        <div class="footer-content">
            <div class="footer-section">
                <h4>DEV-OS</h4>
                <p>نظام تشغيل رقمي متكامل للمطورين.</p>
            </div>
            <div class="footer-section">
                <h4>روابط سريعة</h4>
                <ul class="footer-links">
                    <li><a href="../index.php">الرئيسية</a></li>
                    <li><a href="store.php">المتجر</a></li>
                    <li><a href="blog.php">المدونة</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> DEV-OS. جميع الحقوق محفوظة.</p>
        </div>
    </footer>
    
    <!-- Scripts -->
    <script src="../js/main.js"></script>
</body>
</html>
