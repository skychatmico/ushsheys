<?php
/**
 * DEV-OS Edit App
 * تعديل تطبيق
 */

require_once '../includes/config.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id === 0) {
    redirect('apps.php');
}

try {
    $db = getDB();
    
    // جلب التطبيق
    $stmt = $db->prepare("SELECT * FROM apps WHERE id = ?");
    $stmt->execute([$id]);
    $app = $stmt->fetch();
    
    if (!$app) {
        redirect('apps.php');
    }
    
} catch (Exception $e) {
    redirect('apps.php');
}

$message = '';
$messageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $name = cleanInput($_POST['name']);
        $description = $_POST['description'];
        $version = cleanInput($_POST['version']);
        $category = cleanInput($_POST['category']);
        $developer = cleanInput($_POST['developer']);
        $status = $_POST['status'];
        
        if (empty($name)) {
            throw new Exception('اسم التطبيق مطلوب');
        }
        
        $stmt = $db->prepare("
            UPDATE apps 
            SET name = ?, description = ?, version = ?, category = ?, developer = ?, status = ?
            WHERE id = ?
        ");
        
        $stmt->execute([$name, $description, $version, $category, $developer, $status, $id]);
        
        $message = 'تم تحديث التطبيق بنجاح!';
        
        // تحديث البيانات المعروضة
        $app['name'] = $name;
        $app['description'] = $description;
        $app['version'] = $version;
        $app['category'] = $category;
        $app['developer'] = $developer;
        $app['status'] = $status;
        
    } catch (Exception $e) {
        $message = $e->getMessage();
        $messageType = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل تطبيق | DEV-OS</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        .admin-sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--bg-secondary);
            border-left: 1px solid var(--glass-border);
            z-index: 100;
            overflow-y: auto;
        }
        
        .admin-main {
            margin-right: 280px;
            min-height: 100vh;
            padding: 30px;
        }
        
        .admin-logo {
            padding: 30px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-nav {
            padding: 20px 0;
        }
        
        .admin-nav-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 30px;
            color: var(--text-secondary);
            transition: var(--transition);
            border-right: 3px solid transparent;
        }
        
        .admin-nav-item:hover,
        .admin-nav-item.active {
            background: var(--glass-bg);
            color: var(--text-primary);
            border-right-color: var(--neon-blue);
        }
        
        .admin-nav-item i {
            width: 24px;
            text-align: center;
            color: var(--neon-blue);
        }
        
        .admin-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-title {
            font-size: 28px;
            font-weight: 700;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }
        
        .form-grid .form-group.full-width {
            grid-column: 1 / -1;
        }
        
        .current-file {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-md);
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .current-file-label {
            font-size: 12px;
            color: var(--text-muted);
            margin-bottom: 10px;
        }
        
        .current-file-name {
            font-size: 14px;
            color: var(--neon-blue);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .admin-main {
                margin-right: 0;
            }
            
            .admin-sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <div class="admin-logo">
            <a href="../index.php" class="logo">
                <div class="logo-icon">D</div>
                <span class="logo-text">DEV-OS</span>
            </a>
        </div>
        
        <nav class="admin-nav">
            <a href="index.php" class="admin-nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="articles.php" class="admin-nav-item">
                <i class="fas fa-file-alt"></i>
                <span>المقالات</span>
            </a>
            <a href="apps.php" class="admin-nav-item active">
                <i class="fas fa-mobile-alt"></i>
                <span>التطبيقات</span>
            </a>
            <a href="add-article.php" class="admin-nav-item">
                <i class="fas fa-plus-circle"></i>
                <span>إضافة مقال</span>
            </a>
            <a href="add-app.php" class="admin-nav-item">
                <i class="fas fa-upload"></i>
                <span>رفع تطبيق</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="admin-main">
        <div class="admin-header">
            <h1 class="admin-title">تعديل تطبيق</h1>
            <a href="apps.php" class="btn btn-secondary btn-sm">
                <i class="fas fa-arrow-right"></i>
                العودة
            </a>
        </div>
        
        <?php if ($message): ?>
            <?php echo showAlert($message, $messageType); ?>
        <?php endif; ?>
        
        <div class="glass-card">
            <div class="current-file">
                <div class="current-file-label">الملف الحالي:</div>
                <div class="current-file-name">
                    <i class="fas fa-file-archive"></i>
                    <?php echo basename($app['file_path']); ?> 
                    (<?php echo formatFileSize($app['file_size']); ?>)
                </div>
            </div>
            
            <form method="POST" action="">
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">اسم التطبيق</label>
                        <input type="text" name="name" class="form-input" 
                               value="<?php echo htmlspecialchars($app['name']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">الإصدار</label>
                        <input type="text" name="version" class="form-input" 
                               value="<?php echo htmlspecialchars($app['version']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">القسم</label>
                        <select name="category" class="form-select">
                            <option value="أدوات المطورين" <?php echo $app['category'] === 'أدوات المطورين' ? 'selected' : ''; ?>>أدوات المطورين</option>
                            <option value="محررات الأكواد" <?php echo $app['category'] === 'محررات الأكواد' ? 'selected' : ''; ?>>محررات الأكواد</option>
                            <option value="قواعد البيانات" <?php echo $app['category'] === 'قواعد البيانات' ? 'selected' : ''; ?>>قواعد البيانات</option>
                            <option value="أدوات Git" <?php echo $app['category'] === 'أدوات Git' ? 'selected' : ''; ?>>أدوات Git</option>
                            <option value="اختبار APIs" <?php echo $app['category'] === 'اختبار APIs' ? 'selected' : ''; ?>>اختبار APIs</option>
                            <option value="أخرى" <?php echo $app['category'] === 'أخرى' ? 'selected' : ''; ?>>أخرى</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">الحالة</label>
                        <select name="status" class="form-select">
                            <option value="active" <?php echo $app['status'] === 'active' ? 'selected' : ''; ?>>نشط</option>
                            <option value="inactive" <?php echo $app['status'] === 'inactive' ? 'selected' : ''; ?>>غير نشط</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">المطور</label>
                        <input type="text" name="developer" class="form-input" 
                               value="<?php echo htmlspecialchars($app['developer']); ?>">
                    </div>
                    
                    <div class="form-group full-width">
                        <label class="form-label">وصف التطبيق</label>
                        <textarea name="description" class="form-textarea" rows="5"><?php echo htmlspecialchars($app['description']); ?></textarea>
                    </div>
                    
                    <div class="form-group full-width">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i>
                            حفظ التغييرات
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>
</body>
</html>
