<?php
/**
 * DEV-OS Add Article
 * إضافة مقال جديد
 */

require_once '../includes/config.php';

$message = '';
$messageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = getDB();
        
        $title = cleanInput($_POST['title']);
        $slug = createSlug($title);
        $content = $_POST['content'];
        $excerpt = cleanInput($_POST['excerpt']);
        $category = cleanInput($_POST['category']);
        $tags = cleanInput($_POST['tags']);
        $author = cleanInput($_POST['author']);
        $status = $_POST['status'];
        
        // التحقق من البيانات
        if (empty($title) || empty($content)) {
            throw new Exception('العنوان والمحتوى مطلوبان');
        }
        
        // التأكد من عدم تكرار الـ slug
        $checkStmt = $db->prepare("SELECT id FROM articles WHERE slug = ?");
        $checkStmt->execute([$slug]);
        if ($checkStmt->fetch()) {
            $slug .= '-' . time();
        }
        
        $stmt = $db->prepare("
            INSERT INTO articles (title, slug, content, excerpt, category, tags, author, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([$title, $slug, $content, $excerpt, $category, $tags, $author, $status]);
        
        $message = 'تم إضافة المقال بنجاح!';
        
    } catch (Exception $e) {
        $message = $e->getMessage();
        $messageType = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة مقال | DEV-OS</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        .admin-sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: var(--bg-secondary);
            border-left: 1px solid var(--glass-border);
            z-index: 100;
            overflow-y: auto;
        }
        
        .admin-main {
            margin-right: 280px;
            min-height: 100vh;
            padding: 30px;
        }
        
        .admin-logo {
            padding: 30px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-nav {
            padding: 20px 0;
        }
        
        .admin-nav-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 30px;
            color: var(--text-secondary);
            transition: var(--transition);
            border-right: 3px solid transparent;
        }
        
        .admin-nav-item:hover,
        .admin-nav-item.active {
            background: var(--glass-bg);
            color: var(--text-primary);
            border-right-color: var(--neon-blue);
        }
        
        .admin-nav-item i {
            width: 24px;
            text-align: center;
            color: var(--neon-blue);
        }
        
        .admin-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-title {
            font-size: 28px;
            font-weight: 700;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }
        
        .form-grid .form-group.full-width {
            grid-column: 1 / -1;
        }
        
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .admin-main {
                margin-right: 0;
            }
            
            .admin-sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <div class="admin-logo">
            <a href="../index.php" class="logo">
                <div class="logo-icon">D</div>
                <span class="logo-text">DEV-OS</span>
            </a>
        </div>
        
        <nav class="admin-nav">
            <a href="index.php" class="admin-nav-item">
                <i class="fas fa-tachometer-alt"></i>
                <span>لوحة التحكم</span>
            </a>
            <a href="articles.php" class="admin-nav-item">
                <i class="fas fa-file-alt"></i>
                <span>المقالات</span>
            </a>
            <a href="apps.php" class="admin-nav-item">
                <i class="fas fa-mobile-alt"></i>
                <span>التطبيقات</span>
            </a>
            <a href="add-article.php" class="admin-nav-item active">
                <i class="fas fa-plus-circle"></i>
                <span>إضافة مقال</span>
            </a>
            <a href="add-app.php" class="admin-nav-item">
                <i class="fas fa-upload"></i>
                <span>رفع تطبيق</span>
            </a>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <main class="admin-main">
        <div class="admin-header">
            <h1 class="admin-title">إضافة مقال جديد</h1>
            <a href="index.php" class="btn btn-secondary btn-sm">
                <i class="fas fa-arrow-right"></i>
                العودة
            </a>
        </div>
        
        <?php if ($message): ?>
            <?php echo showAlert($message, $messageType); ?>
        <?php endif; ?>
        
        <div class="glass-card">
            <form method="POST" action="">
                <div class="form-grid">
                    <div class="form-group full-width">
                        <label class="form-label">عنوان المقال</label>
                        <input type="text" name="title" class="form-input" placeholder="أدخل عنوان المقال" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">القسم</label>
                        <select name="category" class="form-select">
                            <option value="برمجة">برمجة</option>
                            <option value="ويب">ويب</option>
                            <option value="موبايل">موبايل</option>
                            <option value="قواعد بيانات">قواعد بيانات</option>
                            <option value="أمن">أمن</option>
                            <option value="أدوات">أدوات</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">الحالة</label>
                        <select name="status" class="form-select">
                            <option value="published">منشور</option>
                            <option value="draft">مسودة</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">الوسوم (مفصولة بفواصل)</label>
                        <input type="text" name="tags" class="form-input" placeholder="Java, برمجة, تعلم">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">الكاتب</label>
                        <input type="text" name="author" class="form-input" value="DEV-OS Team">
                    </div>
                    
                    <div class="form-group full-width">
                        <label class="form-label">ملخص المقال</label>
                        <textarea name="excerpt" class="form-textarea" rows="3" placeholder="ملخص قصير للمقال (يظهر في القوائم)"></textarea>
                    </div>
                    
                    <div class="form-group full-width">
                        <label class="form-label">محتوى المقال (يدعم HTML)</label>
                        <textarea name="content" class="form-textarea" rows="15" placeholder="<h2>عنوان</h2>
<p>محتوى المقال هنا...</p>
<pre><code class='language-java'>// كود هنا</code></pre>" required></textarea>
                    </div>
                    
                    <div class="form-group full-width">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i>
                            حفظ المقال
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>
</body>
</html>
