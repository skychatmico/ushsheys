-- DEV-OS Database Schema
-- نظام تشغيل رقمي - قاعدة البيانات

CREATE DATABASE IF NOT EXISTS dev_os CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dev_os;

-- جدول المقالات
CREATE TABLE IF NOT EXISTS articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    content TEXT NOT NULL,
    excerpt VARCHAR(500),
    category VARCHAR(100),
    tags VARCHAR(255),
    author VARCHAR(100),
    featured_image VARCHAR(255),
    views INT DEFAULT 0,
    status ENUM('published', 'draft') DEFAULT 'published',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_slug (slug),
    INDEX idx_category (category),
    INDEX idx_status (status),
    FULLTEXT INDEX idx_search (title, content, tags)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول التطبيقات
CREATE TABLE IF NOT EXISTS apps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    description TEXT,
    version VARCHAR(50),
    file_path VARCHAR(255) NOT NULL,
    file_size BIGINT,
    icon VARCHAR(255),
    screenshots TEXT,
    category VARCHAR(100),
    developer VARCHAR(100),
    downloads INT DEFAULT 0,
    rating DECIMAL(2,1) DEFAULT 0.0,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_slug (slug),
    INDEX idx_category (category),
    INDEX idx_status (status),
    FULLTEXT INDEX idx_search (name, description, category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول المستخدمين (للوحة التحكم)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'editor') DEFAULT 'editor',
    avatar VARCHAR(255),
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات تجريبية للمقالات
INSERT INTO articles (title, slug, content, excerpt, category, tags, author) VALUES
('مقدمة في لغة Java', 'java-introduction', 
'<h2>ما هي Java؟</h2>
<p>Java هي لغة برمجة كائنية التوجه (Object-Oriented) تتميز بقابلية التشغيل على منصات متعددة (Write Once, Run Anywhere).</p>
<pre><code class="language-java">public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}</code></pre>
<h2>مميزات Java</h2>
<ul>
<li>سهلة التعلم</li>
<li>آمنة وقوية</li>
<li>قابلة للتوسع</li>
</ul>', 
'تعرف على أساسيات لغة Java وكيفية البدء في تعلمها', 
'برمجة', 'Java, برمجة, تعلم', 'DEV-OS Team'),

('دليل شامل لتعلم C++', 'cpp-complete-guide', 
'<h2>لماذا C++؟</h2>
<p>C++ هي لغة برمجة قوية تستخدم في تطوير الأنظمة والألعاب والتطبيقات عالية الأداء.</p>
<pre><code class="language-cpp">#include <iostream>
using namespace std;

int main() {
    cout << "Hello, C++!" << endl;
    return 0;
}</code></pre>
<h2>المفاهيم الأساسية</h2>
<ul>
<li>المؤشرات (Pointers)</li>
<li>الوراثة (Inheritance)</li>
<li>تعدد الأشكال (Polymorphism)</li>
</ul>', 
'دليل شامل لتعلم لغة C++ من الصفر حتى الاحتراف', 
'برمجة', 'C++, برمجة, تعلم', 'DEV-OS Team'),

('أفضل ممارسات تطوير الويب', 'web-development-best-practices', 
'<h2>تطوير الويب الحديث</h2>
<p>في عصر التحول الرقمي، أصبح تطوير الويب من المهارات الأساسية المطلوبة.</p>
<pre><code class="language-javascript">// مثال على كود JavaScript نظيف
const fetchData = async () => {
    try {
        const response = await fetch('/api/data');
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error:', error);
    }
};</code></pre>
<h2>الأدوات الأساسية</h2>
<ul>
<li>HTML5 & CSS3</li>
<li>JavaScript ES6+</li>
<li>React أو Vue</li>
</ul>', 
'تعرف على أفضل الممارسات في تطوير تطبيقات الويب', 
'ويب', 'Web, JavaScript, HTML, CSS', 'DEV-OS Team');

-- بيانات تجريبية للتطبيقات
INSERT INTO apps (name, slug, description, version, file_path, file_size, category, developer) VALUES
('Code Editor Pro', 'code-editor-pro', 
'محرر أكواد احترافي يدعم أكثر من 50 لغة برمجة مع ميزات التلوين التلقائي وإكمال الكود', 
'2.5.1', 'uploads/apps/code-editor-pro.apk', 15728640, 'أدوات المطورين', 'DEV-OS'),

('Database Manager', 'database-manager', 
'تطبيق لإدارة قواعد البيانات MySQL و PostgreSQL من هاتفك', 
'1.8.0', 'uploads/apps/database-manager.apk', 20971520, 'أدوات المطورين', 'DEV-OS'),

('Git Helper', 'git-helper', 
'تطبيق يساعدك على تعلم أوامر Git وإدارة مستودعاتك', 
'3.0.2', 'uploads/apps/git-helper.apk', 12582912, 'أدوات المطورين', 'DEV-OS'),

('API Tester', 'api-tester', 
'اختبر واجهات برمجة التطبيقات REST و GraphQL بسهولة', 
'1.5.0', 'uploads/apps/api-tester.apk', 18350080, 'أدوات المطورين', 'DEV-OS');

-- مستخدم افتراضي للوحة التحكم (كلمة المرور: admin123)
INSERT INTO users (username, email, password_hash, role) VALUES
('admin', 'admin@dev-os.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
