<?php
/**
 * DEV-OS Configuration File
 * ملف إعدادات نظام التشغيل الرقمي
 */

// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'dev_os');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// إعدادات الموقع
define('SITE_URL', 'http://localhost/dev-os');
define('SITE_NAME', 'DEV-OS');
define('SITE_VERSION', '3.0');
define('SITE_DESCRIPTION', 'نظام تشغيل رقمي متكامل للمطورين');

// المسارات
define('ROOT_PATH', dirname(__DIR__));
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('APPS_PATH', UPLOADS_PATH . '/apps');
define('IMAGES_PATH', UPLOADS_PATH . '/images');

// إعدادات الجلسة
session_start();

// دالة الاتصال بقاعدة البيانات باستخدام PDO
function getDB() {
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            throw new Exception("فشل الاتصال بقاعدة البيانات");
        }
    }
    
    return $pdo;
}

// دالة للتحقق من تسجيل الدخول
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// دالة للتحقق من صلاحية المسؤول
function isAdmin() {
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

// دالة إعادة التوجيه
function redirect($url) {
    header("Location: " . $url);
    exit();
}

// دالة تنظيف المدخلات
function cleanInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

// دالة إنشاء slug
function createSlug($string) {
    $string = preg_replace('/[^\p{Arabic}a-zA-Z0-9\s-]/u', '', $string);
    $string = preg_replace('/\s+/', '-', $string);
    $string = trim($string, '-');
    return strtolower($string);
}

// دالة تنسيق حجم الملف
function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}

// دالة تقطيع النص
function excerpt($text, $length = 150) {
    $text = strip_tags($text);
    if (mb_strlen($text, 'UTF-8') > $length) {
        $text = mb_substr($text, 0, $length, 'UTF-8') . '...';
    }
    return $text;
}

// دالة عرض رسائل التنبيه
function showAlert($message, $type = 'success') {
    $colors = [
        'success' => '#10b981',
        'error' => '#ef4444',
        'warning' => '#f59e0b',
        'info' => '#3b82f6'
    ];
    
    $color = $colors[$type] ?? $colors['info'];
    
    return "
    <div class='alert-message' style='background: {$color}20; border: 1px solid {$color}; color: {$color}; padding: 12px 20px; border-radius: 12px; margin-bottom: 20px; backdrop-filter: blur(10px);'>
        <i class='fas fa-" . ($type === 'success' ? 'check-circle' : ($type === 'error' ? 'exclamation-circle' : 'info-circle')) . "'></i>
        {$message}
    </div>";
}
?>
